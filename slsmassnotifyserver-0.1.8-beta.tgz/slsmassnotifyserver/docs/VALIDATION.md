# Automated validation

Browser dependencies are mandatory in the source CI workflow. New 0.1.7 cases
exercise subscriber worker registration under the production CSP and actual
POST navigation to a separate synthetic IdP origin. Missing browser tools fail
required qualification; these fixtures make no production login requests.

Dashboard browser checks also require a local public jQuery asset through `SLS_UI_JQUERY`. CI installs Debian's `libjs-jquery` and supplies `/usr/share/javascript/jquery/jquery.min.js`. This fixture dependency does not add or replace the PBX's jQuery installation.

The VM controller retains a private report on prerequisite failure and bounded
logs on scenario failure. It supports 0.1.6 upgrades, early preparation power
loss, repair, removal and purge. Controller tests are not successful full PBX
VM runs. See the [qualification matrix](QUALIFICATION_MATRIX.md).

`.github/workflows/validation.yml` runs on pushes, pull requests and manual dispatch. It uses a disposable Debian 12 container on a GitHub-hosted runner, read-only repository permissions and a pinned checkout action with persisted credentials disabled. It receives no PBX credentials, release-signing keys or deployment access and does not publish artifacts or install to a PBX.

`tools/lint_source.sh` checks PHP, shell and Python syntax and the mirrored documentation. `tools/run_isolated_tests.sh` discovers the behavior/failure suites registered in the release build, then masks PBX state and sockets with disposable mount, network and PID namespaces. Privileged container access is required for those namespaces and is confined to the disposable runner. Do not run CI on this production PBX as a self-hosted runner.

Run focused suites while developing; run the complete registered set before a candidate release. Register new meaningful behavior tests in `tools/build_tgz.sh` so both CI and release preparation exercise them. A signing step is deliberately absent from CI.

Concurrency regressions cover simultaneous first-directory creation with valid, linked and non-directory replacements; shared desktop limiter reads with exclusive write revalidation; and receipt retry after lock contention. Browser checks complete obsolete HTTP 200 and 401 responses after a new display login and verify that its session and cursor survive. Recording checks retain case-sensitive names and model an unavailable G.722 decoder. Uninstaller checks verify that help and unsupported arguments cannot reach host operations.

Media-policy qualification starts a separate Apache/mod_php instance inside the private network namespace with dummy configuration and files. It exercises both normal URLs and legacy API prefix aliases, exact image/XML bytes, HEAD requests, network/proxy enforcement, expiry, and failures. Apache and PHP packages are installed only in the disposable CI container; the test does not reload or reconfigure a production web service.

Location/geography suites exercise inherited and overridden coordinates, age exclusions, date-line and boundary selection, explicit coordinate/exclusion review, revision conflicts, frozen audiences and reused desktop identities. The actual page controller is checked for CSRF, bounds and action dispatch, and deterministic editor fixtures cover large desktop catalogs. Responsive map interaction remains an explicit release acceptance check in a supported browser; the deterministic PHP/Node gates do not qualify it. That check sends no notifications.

CI does not prove handset behavior, public-edge HTTPS operation, provider delivery, full-fleet capacity or fresh FreePBX installation/restore compatibility. Those checks remain separate acceptance gates on approved targets and disposable PBX systems. The workflow is prepared locally and requires publication of the repository changes before GitHub can execute it; no remote CI success is claimed by adding the file.

Private browser qualification also renders Dashboard, Weather, Lightning, schedules, logs, delivery details, Help, setup and incident pages at 1440 and 390 pixels. Checks cover rendering/script failures and document overflow; Help is tested with all topics expanded and native keyboard controls. The full General Settings FormData is submitted to the actual save method using private storage, verifying advertised host/ports/HTTPS, credential preservation, SMS provider selection/draft retention and resource-counter refresh. Paging, locations, operators and trigger editors have separate actual-controller workflow checks. These private fixtures use synthetic data and blocked/intercepted network requests, never production configuration writes or provider delivery.
