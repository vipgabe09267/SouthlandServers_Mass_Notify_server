<?php
// Southland Servers Mass Notifications Server by the Southland Servers Group
$settings = is_array($settings ?? null) ? $settings : [];
$saveResult = $save_result ?? null;
$extensions = is_array($available_extensions ?? null) ? $available_extensions : [];
$desktopClients = array_values(array_filter((array)($available_desktop_clients ?? []), 'is_array'));
$voices = is_array($available_voices ?? null) ? $available_voices : [];
$setup = is_array($settings['setup'] ?? null) ? $settings['setup'] : [];
$criticalEvents = is_array($settings['quiet_critical_events'] ?? null) ? $settings['quiet_critical_events'] : [];
$selectedRecipients = array_fill_keys((array)($settings['alert_recipients'] ?? []), true);
$xweather = is_array($settings['xweather'] ?? null) ? $settings['xweather'] : [];
$setupWeatherZones = is_array($settings['nws_zones'] ?? null) ? $settings['nws_zones'] : [];
$setupPrimaryWeatherZone = is_array($setupWeatherZones[0] ?? null) ? $setupWeatherZones[0] : [];
$selectedWeatherDesktops = array_fill_keys((array)($setupPrimaryWeatherZone['desktop_clients'] ?? []), true);
$selectedWeatherEmails = implode("\n", (array)($setupPrimaryWeatherZone['email_recipients'] ?? []));
$setupAdaptiveZone = (string)($xweather['adaptive_nws_zone_id'] ?? ($setupWeatherZones[0]['id'] ?? ''));
$lightningRecipients = array_fill_keys((array)($xweather['recipients'] ?? []), true);
$setupTones = is_array($available_tones ?? null) ? $available_tones : [];
$setupSystemSounds = is_array($available_system_sounds ?? null) ? $available_system_sounds : [];
$dismissible = !empty($dismissible);
$weatherSetupEnabled = (($settings['enabled'] ?? '0') === '1');
$lightningSetupEnabled = (($xweather['enabled'] ?? '0') === '1');
$setupAddress = \FreePBX\modules\SlsAdvertisedAddress::fields($settings);
?>
<style>
	.sls-setup-backdrop {
		position: fixed;
		z-index: 1040;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		background: rgba(17, 24, 39, 0.72);
	}
	.sls-setup-modal-shell {
		position: fixed;
		z-index: 1050;
		top: 20px;
		right: 20px;
		bottom: 20px;
		left: 20px;
		overflow: auto;
	}
	.sls-setup-modal-dialog {
		max-width: 1100px;
		margin: 0 auto;
		background: #fff;
		border-radius: 6px;
		box-shadow: 0 18px 48px rgba(0, 0, 0, 0.35);
	}
	.sls-setup-modal-content {
		padding: 20px;
	}
	.sls-setup-section { margin:22px 0; padding:18px; border:1px solid #d9e2ec; border-radius:10px; background:#f8fafc; }
	.sls-setup-section h3 { margin:0 0 6px; }
	.sls-setup-enable-row { max-width:360px; margin-top:14px; }
	.sls-setup-option-details { margin-top:14px; padding-top:16px; border-top:1px solid #d9e2ec; }
	.sls-setup-option-details[hidden], [data-sls-setup-integration][hidden] { display:none !important; }
	.sls-setup-modal-content .checkbox > label,
	.sls-setup-modal-content label.checkbox-inline { display:inline-flex; align-items:flex-start; gap:8px; padding-left:0; line-height:1.35; }
	.sls-setup-modal-content .checkbox input[type="checkbox"],
	.sls-setup-modal-content label.checkbox-inline input[type="checkbox"] { position:static; flex:0 0 auto; margin:2px 0 0 !important; }
	.sls-setup-modal-content label.checkbox-inline { margin:0 14px 8px 0; }
	.sls-setup-toggle { position:relative; display:inline-block; width:48px; height:26px; vertical-align:middle; margin-right:8px; }
	.sls-setup-toggle input { opacity:0; width:0; height:0; }
	.sls-setup-toggle span { position:absolute; inset:0; border-radius:26px; background:#cbd5e1; cursor:pointer; transition:.2s; }
	.sls-setup-toggle span:before { content:""; position:absolute; width:20px; height:20px; left:3px; top:3px; border-radius:50%; background:#fff; transition:.2s; }
	.sls-setup-toggle input:checked + span { background:#6d28d9; }
	.sls-setup-toggle input:checked + span:before { transform:translateX(22px); }
	.sls-setup-adaptive-card { border:1px solid #86efac; border-radius:8px; padding:12px 14px; background:#ecfdf5; color:#166534; transition:background-color .2s,border-color .2s,color .2s; }
	.sls-setup-adaptive-card.is-disabled { border-color:#fca5a5; background:#fef2f2; color:#991b1b; }
	.sls-setup-adaptive-card .sls-setup-toggle { margin-bottom:0; }
	.sls-setup-adaptive-card .sls-setup-toggle input:checked + span { background:#16a34a; }
	.sls-setup-adaptive-state { display:inline-flex; align-items:center; gap:7px; vertical-align:middle; }
	.sls-setup-adaptive-copy { display:block; margin:8px 0 0; color:inherit; }
	@media (max-width: 767px) {
		.sls-setup-modal-shell {
			top: 8px;
			right: 8px;
			bottom: 8px;
			left: 8px;
		}
		.sls-setup-modal-content {
			padding: 12px 15px;
		}
	}
</style>
<div class="sls-setup-backdrop"></div>
<div class="sls-setup-modal-shell" role="dialog" aria-modal="true">
<div class="sls-setup-modal-dialog">
<div class="container-fluid sls-setup-modal-content">
	<?php if ($dismissible) { ?>
		<button type="button" class="close sls-setup-dismiss" aria-label="<?php echo htmlspecialchars(_('Close setup wizard')); ?>" style="font-size: 30px; opacity: .75;">
			<span aria-hidden="true">&times;</span>
		</button>
	<?php } ?>
	<?php echo load_view(__DIR__ . '/hero.php', ['hero_image' => $hero_image ?? '']); ?>
	<div class="row">
		<div class="col-sm-12">
			<h2><i class="fa fa-magic text-primary" aria-hidden="true"></i> <?php echo _('Setup Wizard'); ?></h2>
			<p class="text-muted">
				<?php echo _('Thank you for installing the Southland Servers Mass Notification System. Complete this wizard before using the Mass Notifications module.'); ?>
			</p>
			<p>
				<a href="<?php echo htmlspecialchars($project_url ?? 'https://southlandservers.xyz/projects'); ?>" target="_blank" rel="noopener"><?php echo _('Project'); ?></a>
				|
				<a href="<?php echo htmlspecialchars($discord_url ?? 'https://southlandservers.xyz/discord'); ?>" target="_blank" rel="noopener"><?php echo _('Discord'); ?></a>
				|
				<a href="<?php echo htmlspecialchars($github_url ?? 'https://github.com/vipgabe09267/SouthlandServers_Mass_Notify_server'); ?>" target="_blank" rel="noopener"><?php echo _('GitHub'); ?></a>
			</p>

			<?php if (is_array($saveResult)) { ?>
				<div class="alert alert-<?php echo !empty($saveResult['success']) ? 'success' : 'warning'; ?>">
					<?php echo htmlspecialchars($saveResult['message']); ?>
					<?php if (!empty($saveResult['errors'])) { ?>
						<ul>
							<?php foreach ($saveResult['errors'] as $error) { ?>
								<li><?php echo htmlspecialchars($error); ?></li>
							<?php } ?>
						</ul>
					<?php } ?>
				</div>
			<?php } ?>

			<?php if (!empty($setup['completed'])) { ?>
				<div class="alert alert-success"><?php echo _('Setup is already complete. You can rerun this wizard to update first-run choices.'); ?></div>
			<?php } else { ?>
				<div class="alert alert-danger">
					<strong><?php echo _('Warning'); ?>:</strong>
					<?php echo _('This project is still beta software and is not production ready. Use it at your own risk.'); ?>
				</div>
			<?php } ?>

				<form method="post" action="config.php?display=slsmassnotifyserver">
					<input type="hidden" name="sls_setup_form_present" value="1">
					<input type="hidden" name="slsmassnotifyserver_action" value="save_setup_wizard">
					<input type="hidden" name="slsmassnotifyserver_csrf" value="<?php echo htmlspecialchars((string)($csrf_token ?? '')); ?>">

				<h3><i class="fa fa-check-square-o text-success" aria-hidden="true"></i> <?php echo _('Required Acknowledgements'); ?></h3>
				<div class="checkbox">
					<label>
						<input type="checkbox" name="beta_agree" value="1" <?php echo !empty($setup['beta_accepted']) ? 'checked' : ''; ?>>
						<?php echo _('I understand this beta is non-production-ready and I use it at my own risk.'); ?>
					</label>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading"><?php echo _('AGPL-3.0 License Notice'); ?></div>
					<div class="panel-body" style="max-height: 180px; overflow: auto;">
						<p><?php echo _('Southland Servers Mass Notifications Server is intended to be licensed under the GNU Affero General Public License version 3. Network users must be able to receive the corresponding source code under the AGPL terms.'); ?></p>
						<p><a href="https://www.gnu.org/licenses/agpl-3.0.html" target="_blank" rel="noopener"><?php echo _('Read the AGPL-3.0 license'); ?></a></p>
					</div>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" name="agpl_agree" value="1" <?php echo !empty($setup['agpl_accepted']) ? 'checked' : ''; ?>>
						<?php echo _('I accept the AGPL-3.0 license notice.'); ?>
					</label>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading"><?php echo _('EULA'); ?></div>
					<pre style="max-height: 220px; overflow: auto; white-space: pre-wrap;"><?php echo htmlspecialchars((string)($eula_text ?? '')); ?></pre>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" name="eula_agree" value="1" <?php echo !empty($setup['eula_accepted']) ? 'checked' : ''; ?>>
						<?php echo _('I have read and accept the EULA.'); ?>
					</label>
				</div>

				<section class="sls-setup-section" aria-labelledby="sls-setup-weather-title">
				<h3 id="sls-setup-weather-title"><i class="fa fa-cloud text-primary" aria-hidden="true"></i> <?php echo _('Weather Alerts'); ?></h3>
				<p class="help-block"><?php echo _('Optional. Supports United States locations and zones through the U.S. National Weather Service weather.gov API only.'); ?></p>
				<div class="sls-setup-enable-row form-group">
					<label for="sls-setup-weather-enabled"><?php echo _('Set up Weather Alerts now?'); ?></label>
					<select class="form-control" id="sls-setup-weather-enabled" name="enabled">
						<option value="0" <?php echo !$weatherSetupEnabled ? 'selected' : ''; ?>><?php echo _('No'); ?></option>
						<option value="1" <?php echo $weatherSetupEnabled ? 'selected' : ''; ?>><?php echo _('Yes'); ?></option>
					</select>
				</div>
				<div id="sls-setup-weather-details" class="sls-setup-option-details" <?php echo !$weatherSetupEnabled ? 'hidden' : ''; ?>>
				<div class="row">
					<div class="col-md-3">
						<div class="form-group">
							<label><?php echo _('NWS Zone/County'); ?></label>
							<input class="form-control" name="nws_zone" value="<?php echo htmlspecialchars($settings['nws_zone'] ?? ''); ?>" placeholder="TXZ163">
							<p class="help-block"><?php echo _('Open the official zone maps, choose your state, and find the three-digit number covering your location. Enter your state abbreviation, Z, and that number; for example, Texas zone 163 is TXZ163.'); ?> <a href="https://www.weather.gov/pimar/PubZone" target="_blank" rel="noopener noreferrer"><?php echo _('Open official NWS zone maps'); ?> <i class="fa fa-external-link" aria-hidden="true"></i></a></p>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label><?php echo _('NWS API Base URL'); ?></label>
							<input class="form-control" name="nws_api_base_url" value="https://api.weather.gov" readonly aria-readonly="true">
							<p class="help-block"><?php echo _('Weather Alerts uses only the official U.S. weather.gov API endpoint.'); ?></p>
						</div>
					</div>
				</div>
				<div class="form-group">
					<label><?php echo _('NWS Recipient Extensions'); ?></label>
					<div class="row">
						<?php foreach ($extensions as $target) { ?>
							<div class="col-sm-3">
								<label class="checkbox-inline">
									<input type="checkbox" name="alert_recipients[]" value="<?php echo htmlspecialchars($target['extension']); ?>" <?php echo isset($selectedRecipients[$target['extension']]) ? 'checked' : ''; ?>>
									<?php echo htmlspecialchars($target['extension']); ?>
									<?php if (($target['name'] ?? '') !== '') { echo ' - ' . htmlspecialchars($target['name']); } ?>
								</label>
							</div>
						<?php } ?>
					</div>
				</div>
				<div class="form-group">
					<label><?php echo _('NWS Desktop Clients'); ?></label>
					<div class="row">
							<?php foreach ($desktopClients as $desktopClient) { $desktopUsername = (string)($desktopClient['username'] ?? ''); $desktopEnabled = !empty($desktopClient['enabled']); $desktopClientId = trim((string)($desktopClient['client_id'] ?? '')); $desktopName = trim((string)($desktopClient['name'] ?? '')); $desktopIdentity = $desktopName !== '' && $desktopName !== $desktopUsername ? $desktopName . ' — ' . $desktopUsername : $desktopUsername; if ($desktopClientId !== '') { $desktopIdentity .= ' · ' . _('client ID') . ' ' . $desktopClientId; } ?>
								<div class="col-sm-4"><label class="checkbox-inline"><input type="checkbox" name="nws_desktop_clients[]" value="<?php echo htmlspecialchars($desktopUsername); ?>" <?php echo isset($selectedWeatherDesktops[$desktopUsername]) ? 'checked' : ''; ?> <?php echo !$desktopEnabled ? 'disabled data-sls-permanent-disabled="1"' : ''; ?>> <?php echo htmlspecialchars($desktopIdentity); ?> <span class="text-muted"><?php echo $desktopEnabled ? _('enabled') : _('disabled'); ?></span></label></div>
						<?php } ?>
						<?php if (empty($desktopClients)) { ?><div class="col-xs-12 text-muted"><?php echo _('Desktop clients can be added later from General Settings.'); ?></div><?php } ?>
					</div>
					<p class="help-block"><?php echo _('Select at least one phone extension or desktop client for the first weather zone.'); ?></p>
				</div>
				<div class="form-group">
					<label for="sls-setup-weather-email"><?php echo _('Zone Email Recipients'); ?></label>
					<textarea class="form-control" id="sls-setup-weather-email" name="nws_email_recipients" rows="2" maxlength="4096" placeholder="weather-team@example.com"><?php echo htmlspecialchars($selectedWeatherEmails); ?></textarea>
					<p class="help-block"><?php echo _('Optional. Only live alerts from this zone use these addresses. Up to 50 unique addresses are allowed. Manual tests do not send email.'); ?></p>
				</div>
				<div class="row">
					<div class="col-md-3">
						<label><?php echo _('Quiet Hours'); ?></label>
						<select class="form-control" name="quiet_hours_enabled">
							<option value="0" <?php echo empty($settings['quiet_hours_enabled']) ? 'selected' : ''; ?>><?php echo _('Disabled'); ?></option>
							<option value="1" <?php echo !empty($settings['quiet_hours_enabled']) ? 'selected' : ''; ?>><?php echo _('Enabled'); ?></option>
						</select>
					</div>
					<div class="col-md-3">
						<label><?php echo _('Start'); ?></label>
						<input class="form-control" name="quiet_hours_start" value="<?php echo htmlspecialchars($settings['quiet_hours_start'] ?? '21:00'); ?>">
					</div>
					<div class="col-md-3">
						<label><?php echo _('End'); ?></label>
						<input class="form-control" name="quiet_hours_end" value="<?php echo htmlspecialchars($settings['quiet_hours_end'] ?? '06:00'); ?>">
					</div>
					<div class="col-md-3">
						<label><?php echo _('Critical Bypass Events'); ?></label>
						<input class="form-control" name="quiet_critical_events[]" value="<?php echo htmlspecialchars(implode(', ', $criticalEvents)); ?>">
						<p class="help-block"><?php echo _('Comma-separated event names are accepted.'); ?></p>
					</div>
				</div>
				</div>
				</section>

				<section class="sls-setup-section" aria-labelledby="sls-setup-lightning-title">
				<h3 id="sls-setup-lightning-title"><i class="fa fa-bolt text-warning" aria-hidden="true"></i> <?php echo _('Lightning Alerts'); ?></h3>
				<p class="help-block"><?php echo _('Optional lightning monitoring is separate from NWS. It alerts once when a storm enters the radius and can optionally announce an all clear after the storm leaves.'); ?></p>
				<div class="sls-setup-enable-row form-group">
					<label for="sls-setup-lightning-enabled"><?php echo _('Set up Lightning Alerts now?'); ?></label>
					<select class="form-control" id="sls-setup-lightning-enabled" name="xweather[enabled]"><option value="0" <?php echo !$lightningSetupEnabled ? 'selected' : ''; ?>><?php echo _('No'); ?></option><option value="1" <?php echo $lightningSetupEnabled ? 'selected' : ''; ?>><?php echo _('Yes'); ?></option></select>
				</div>
				<div id="sls-setup-lightning-details" class="sls-setup-option-details" <?php echo !$lightningSetupEnabled ? 'hidden' : ''; ?>>
				<div class="row">
					<div class="col-md-2"><div class="form-group"><label><?php echo _('Location'); ?></label><input class="form-control" name="xweather[location]" aria-label="<?php echo htmlspecialchars(_('Location'), ENT_QUOTES, 'UTF-8'); ?>" value="<?php echo htmlspecialchars($xweather['location'] ?? ''); ?>" placeholder="Round Rock, TX or 30.5083,-97.6789"></div></div>
					<div class="col-md-2"><div class="form-group"><label><?php echo _('Radius (miles)'); ?></label><input class="form-control" type="number" min="1" max="62" name="xweather[radius_miles]" aria-label="<?php echo htmlspecialchars(_('Radius (miles)'), ENT_QUOTES, 'UTF-8'); ?>" value="<?php echo (int)($xweather['radius_miles'] ?? 25); ?>"></div></div>
					<div class="col-md-2"><div class="form-group"><label><?php echo _('API period'); ?></label><select class="form-control" name="xweather[query_interval_minutes]" aria-label="<?php echo htmlspecialchars(_('API period'), ENT_QUOTES, 'UTF-8'); ?>"><?php for ($minutes = 1; $minutes <= 10; $minutes++) { ?><option value="<?php echo $minutes; ?>" <?php echo (int)($xweather['query_interval_minutes'] ?? 4) === $minutes ? 'selected' : ''; ?>><?php echo sprintf(_('%d min'), $minutes); ?></option><?php } ?></select><p class="help-block text-danger"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <?php echo _('Continuous polling may exceed the provider allowance. Review adaptive protection and your account limits.'); ?></p></div></div>
					<div class="col-md-3"><div class="form-group"><label><?php echo _('Strike type'); ?></label><select class="form-control" name="xweather[strike_type]" aria-label="<?php echo htmlspecialchars(_('Strike type'), ENT_QUOTES, 'UTF-8'); ?>"><option value="cloud_to_ground" <?php echo ($xweather['strike_type']??'cloud_to_ground')==='cloud_to_ground'?'selected':''; ?>><?php echo _('Cloud to ground'); ?></option><option value="cloud_to_cloud" <?php echo ($xweather['strike_type']??'')==='cloud_to_cloud'?'selected':''; ?>><?php echo _('Cloud to cloud'); ?></option><option value="both" <?php echo ($xweather['strike_type']??'')==='both'?'selected':''; ?>><?php echo _('Both'); ?></option></select></div></div>
					<div class="col-md-3"><div class="form-group"><label><?php echo _('After storm leaves'); ?></label><select class="form-control" name="xweather[all_clear]" aria-label="<?php echo htmlspecialchars(_('After storm leaves'), ENT_QUOTES, 'UTF-8'); ?>"><option value="none" <?php echo ($xweather['all_clear'] ?? 'none') === 'none' ? 'selected' : ''; ?>><?php echo _('Do nothing'); ?></option><option value="send" <?php echo ($xweather['all_clear'] ?? 'none') === 'send' ? 'selected' : ''; ?>><?php echo _('Send all-clear message'); ?></option></select></div></div>
				</div>
				<p class="help-block"><?php echo _('Xweather uses one through four minutes, default four, to overlap its five-minute observations. Tempest and Meteomatics allow up to ten minutes with bounded backfill.'); ?></p>
				<div class="row"><div class="col-md-5"><div class="form-group"><label><?php echo _('Adaptive protection'); ?></label><div id="sls-setup-adaptive-card" class="sls-setup-adaptive-card <?php echo (!array_key_exists('adaptive_free_tier', $xweather) || !empty($xweather['adaptive_free_tier'])) ? 'is-enabled' : 'is-disabled'; ?>"><input type="hidden" name="xweather[adaptive_free_tier]" value="0"><label class="sls-setup-toggle" aria-label="<?php echo htmlspecialchars(_('Toggle adaptive protection')); ?>"><input id="sls-setup-adaptive" type="checkbox" name="xweather[adaptive_free_tier]" value="1" <?php echo !array_key_exists('adaptive_free_tier', $xweather) || !empty($xweather['adaptive_free_tier']) ? 'checked' : ''; ?>><span></span></label><span class="sls-setup-adaptive-state"><i id="sls-setup-adaptive-shield" class="fa fa-shield" aria-hidden="true"></i><strong id="sls-setup-adaptive-label"></strong></span><p class="sls-setup-adaptive-copy"><?php echo _('Enabled polls Xweather only for a qualifying current Weather.gov alert, the structured thunder forecast period active at that time, or the grace period. Disabled polls continuously at the configured API period.'); ?></p></div></div></div><div class="col-md-4"><div class="form-group"><label><?php echo _('Weather trigger zone'); ?></label><select class="form-control" id="sls-setup-adaptive-zone" name="xweather[adaptive_nws_zone_id]" aria-label="<?php echo htmlspecialchars(_('Weather trigger zone'), ENT_QUOTES, 'UTF-8'); ?>"><option value=""><?php echo _('Select a configured weather zone'); ?></option><?php foreach ($setupWeatherZones as $zoneGroup) { ?><option value="<?php echo htmlspecialchars((string)($zoneGroup['id'] ?? '')); ?>" <?php echo $setupAdaptiveZone === (string)($zoneGroup['id'] ?? '') ? 'selected' : ''; ?>><?php echo htmlspecialchars((string)($zoneGroup['name'] ?? $zoneGroup['zone'] ?? '') . ' — ' . (string)($zoneGroup['zone'] ?? '')); ?></option><?php } ?></select></div></div><div class="col-md-3"><div class="form-group"><label><?php echo _('Storm-mode grace'); ?></label><select class="form-control" name="xweather[adaptive_grace_minutes]" aria-label="<?php echo htmlspecialchars(_('Storm-mode grace'), ENT_QUOTES, 'UTF-8'); ?>"><?php foreach ([5, 10, 15, 30, 45, 60, 90, 120] as $grace) { ?><option value="<?php echo $grace; ?>" <?php echo (int)($xweather['adaptive_grace_minutes'] ?? 60) === $grace ? 'selected' : ''; ?>><?php echo sprintf(_('%d minutes'), $grace); ?></option><?php } ?></select><p class="help-block"><?php echo _('Default 60 minutes.'); ?></p></div></div></div>
				<div class="alert alert-warning"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <?php echo _('Adaptive mode is recommended for the 15,000-token free allowance. It requires Weather Alerts and at least one weather zone. A future thunder period is remembered but does not start paid Xweather polling before that period begins; unexpected lightning can still be missed.'); ?></div>
				<div class="form-group"><label><i class="fa fa-flask" aria-hidden="true"></i> <?php echo _('Lightning provider'); ?> <span class="label label-info">Labs</span></label><select class="form-control" name="xweather[provider]" aria-label="<?php echo htmlspecialchars(_('Lightning provider'), ENT_QUOTES, 'UTF-8'); ?>" id="sls-setup-lightning-provider"><?php foreach (['xweather'=>'Xweather (default)','tempest'=>'Tempest — paid Lightning API','meteomatics'=>'Meteomatics — Lightning WFS'] as $key=>$label) { ?><option value="<?php echo $key; ?>" <?php echo ($xweather['provider']??'xweather')===$key?'selected':''; ?>><?php echo htmlspecialchars($label); ?></option><?php } ?></select><p class="help-block"><?php echo _('Tempest requires an API key; Meteomatics requires a username and password. Both need coordinates. Enable after provider acceptance testing.'); ?></p></div><div class="row"><div class="col-md-6"><div class="form-group"><label><?php echo _('Client ID, API key or username'); ?></label><input class="form-control" name="xweather[client_id]" aria-label="<?php echo htmlspecialchars(_('Client ID, API key or username'), ENT_QUOTES, 'UTF-8'); ?>" value="<?php echo htmlspecialchars($xweather['client_id'] ?? ''); ?>" autocomplete="off"></div></div><div class="col-md-6"><div class="form-group"><label><?php echo _('Client secret or password'); ?></label><input class="form-control" type="password" name="xweather[client_secret]" aria-label="<?php echo htmlspecialchars(_('Client secret or password'), ENT_QUOTES, 'UTF-8'); ?>" value="" placeholder="<?php echo !empty($xweather['client_secret']) ? htmlspecialchars(_('Stored; leave blank to keep')) : ''; ?>" autocomplete="new-password"></div></div></div><p class="help-block"><a href="https://www.xweather.com/docs/weather-api/getting-started" target="_blank" rel="noopener noreferrer"><i class="fa fa-external-link" aria-hidden="true"></i> <?php echo _('Create an Xweather account and API access keys'); ?></a></p>
				<div class="form-group"><label><?php echo _('Lightning Recipients'); ?></label><div class="row"><?php foreach ($extensions as $target) { ?><div class="col-sm-3"><label class="checkbox-inline"><input type="checkbox" name="xweather[recipients][]" value="<?php echo htmlspecialchars($target['extension']); ?>" <?php echo isset($lightningRecipients[$target['extension']]) ? 'checked' : ''; ?>> <?php echo htmlspecialchars($target['extension'] . (($target['name'] ?? '') !== '' ? ' - ' . $target['name'] : '')); ?></label></div><?php } ?></div></div>
				<div class="row">
				<?php foreach (['opening' => _('Lightning Pre-tone'), 'closing' => _('Lightning Closing Tone')] as $prefix => $label) { $selectedTone = (string)($xweather[$prefix . '_tone'] ?? ($prefix === 'opening' ? 'opening_Lightning_alert' : '')); ?>
					<div class="col-md-6"><div class="form-group"><label><?php echo $label; ?></label><select class="form-control" name="xweather[<?php echo $prefix; ?>_tone]"><?php if ($prefix === 'opening') { ?><option value="opening_Lightning_alert" <?php echo $selectedTone === 'opening_Lightning_alert' ? 'selected' : ''; ?>><?php echo _('Default — Lightning_alert.mp3'); ?></option><?php } ?><?php if ($selectedTone === 'use_default') { ?><option value="use_default" selected><?php echo _('Legacy weather default'); ?></option><?php } ?><option value="" <?php echo $selectedTone === '' ? 'selected' : ''; ?>><?php echo _('None'); ?></option><optgroup label="<?php echo htmlspecialchars(_('Mass Notify tones')); ?>"><?php foreach ($setupTones as $tone) { ?><option value="<?php echo htmlspecialchars($tone); ?>" <?php echo $selectedTone === $tone ? 'selected' : ''; ?>><?php echo htmlspecialchars(str_replace('_', ' ', $tone)); ?></option><?php } ?></optgroup><?php if ($setupSystemSounds) { ?><optgroup label="<?php echo htmlspecialchars(_('FreePBX System Recordings')); ?>"><?php foreach ($setupSystemSounds as $sound) { ?><option value="<?php echo htmlspecialchars($sound['value']); ?>"><?php echo htmlspecialchars($sound['label']); ?></option><?php } ?></optgroup><?php } ?></select></div></div>
				<?php } ?>
				</div>
				<div class="row"><div class="col-md-4"><div class="form-group"><label><?php echo _('Lightning TTS Volume'); ?></label><div class="input-group"><input class="form-control" name="xweather[tts_volume]" aria-label="<?php echo htmlspecialchars(_('Lightning TTS Volume'), ENT_QUOTES, 'UTF-8'); ?>" type="number" min="1" max="200" value="<?php echo (int)($xweather['tts_volume'] ?? ($settings['nws_tts_volume'] ?? 25)); ?>"><span class="input-group-addon">%</span></div><p class="help-block"><?php echo _('Default 25%. Coordinate locations are spoken as “this area.”'); ?></p></div></div></div>
				<div class="row"><div class="col-md-4"><div class="form-group"><label style="display:block"><?php echo _('Lightning Quiet Hours'); ?></label><label class="sls-setup-toggle"><input type="checkbox" name="xweather[quiet_hours_enabled]" value="1" <?php echo !empty($xweather['quiet_hours_enabled']) ? 'checked' : ''; ?>><span></span></label><strong><?php echo !empty($xweather['quiet_hours_enabled']) ? _('Enabled') : _('Disabled'); ?></strong></div></div><div class="col-md-4"><div class="form-group"><label><?php echo _('Start'); ?></label><input class="form-control" name="xweather[quiet_hours_start]" aria-label="<?php echo htmlspecialchars(_('Start'), ENT_QUOTES, 'UTF-8'); ?>" value="<?php echo htmlspecialchars($xweather['quiet_hours_start'] ?? '21:00'); ?>"></div></div><div class="col-md-4"><div class="form-group"><label><?php echo _('End'); ?></label><input class="form-control" name="xweather[quiet_hours_end]" aria-label="<?php echo htmlspecialchars(_('End'), ENT_QUOTES, 'UTF-8'); ?>" value="<?php echo htmlspecialchars($xweather['quiet_hours_end'] ?? '06:00'); ?>"></div></div></div>
				</div>
				</section>

				<h3><i class="fa fa-key text-muted" aria-hidden="true"></i> <?php echo _('Remote API'); ?></h3>
				<div class="form-group">
					<label for="sls-setup-host"><i class="fa fa-globe text-primary" aria-hidden="true"></i> <?php echo _('Advertised PBX hostname'); ?></label>
					<input id="sls-setup-host" name="advertised_pbx_host" class="form-control" maxlength="253" value="<?php echo htmlspecialchars($setupAddress['host'], ENT_QUOTES, 'UTF-8'); ?>" disabled>
					<p class="help-block"><?php echo _('SLS saves this address in the .config file. A later DNS or operating-system hostname change does not update it automatically.'); ?></p>
					<label class="checkbox-inline"><input id="sls-setup-address-change" name="sls_address_change" type="checkbox" value="1" aria-controls="sls-setup-ports"> <?php echo _('Set hostname or forwarded ports'); ?></label>
					<fieldset id="sls-setup-ports" disabled hidden>
						<div class="row">
							<?php foreach (['api'=>_('Desktop HTTPS port'), 'control'=>_('Control API HTTPS port'), 'media'=>_('Phone image port')] as $kind=>$label) { ?>
							<div class="col-sm-4 form-group"><label for="sls-setup-port-<?php echo $kind; ?>"><?php echo $label; ?></label><input id="sls-setup-port-<?php echo $kind; ?>" class="form-control" name="advertised_<?php echo $kind; ?>_port" type="number" min="1" max="65535" step="1" required value="<?php echo (int)$setupAddress[$kind.'_port']; ?>"></div>
							<?php } ?>
						</div>
						<p class="help-block"><?php echo _('Enter the external ports your clients use. HTTPS normally uses 443; HTTP phone images normally use 80. Router forwarding and proxy ports may differ from the PBX listener. SLS saves the advertised URLs without changing the firewall, router, DNS or certificates.'); ?></p>
					</fieldset>
					<div id="sls-setup-address-preview" class="well well-sm" style="white-space:pre-line;overflow-wrap:anywhere" aria-live="polite"><?php echo htmlspecialchars(_('Desktop API:').' '.($settings['sipnotify']['base_url'] ?? '')."\n"._('Control API:').' '.($settings['control_api']['base_url'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></div>
				</div>
				<div class="form-group">
					<label><?php echo _('Phone Image Transport'); ?></label>
					<select class="form-control" name="sipnotify_media_scheme" aria-label="<?php echo htmlspecialchars(_('Phone Image Transport'), ENT_QUOTES, 'UTF-8'); ?>">
						<option value="http" <?php echo (($settings['sipnotify']['media_scheme'] ?? 'https') === 'http') ? 'selected' : ''; ?>><?php echo _('HTTP - Legacy phone compatibility'); ?></option>
						<option value="https" <?php echo (($settings['sipnotify']['media_scheme'] ?? 'https') === 'https') ? 'selected' : ''; ?>><?php echo _('HTTPS - Requires phone-compatible certificate and TLS'); ?></option>
					</select>
					<p class="help-block"><?php echo _('This affects generated phone image files only. Control and desktop API authentication remain HTTPS.'); ?></p>
				</div>
				<div class="form-group">
					<label><?php echo _('Enable Control API'); ?></label>
					<select class="form-control" name="control_api_enabled" aria-label="<?php echo htmlspecialchars(_('Enable Control API'), ENT_QUOTES, 'UTF-8'); ?>">
						<option value="0" <?php echo empty($settings['control_api']['enabled']) ? 'selected' : ''; ?>><?php echo _('No'); ?></option>
						<option value="1" <?php echo !empty($settings['control_api']['enabled']) ? 'selected' : ''; ?>><?php echo _('Yes'); ?></option>
					</select>
					<p class="help-block"><?php echo htmlspecialchars($settings['control_api']['base_url'] ?? ''); ?></p>
				</div>

				<h3><i class="fa fa-phone text-primary" aria-hidden="true"></i> <?php echo _('SIP NOTIFY Phones'); ?></h3>
				<p class="help-block"><?php echo _('Phone notifications are sent directly through Asterisk/PJSIP to registered extensions. The sender detects common phone vendors from registered contacts. Manual format overrides can be added later in General Settings if an endpoint is unknown or needs a forced format.'); ?></p>

				<h3><i class="fa fa-volume-up text-success" aria-hidden="true"></i> <?php echo _('Audio Profiles and TTS'); ?></h3>
				<div class="alert alert-info"><i class="fa fa-random" aria-hidden="true"></i> <?php echo _('Regular paging, Weather Alerts, and Lightning Alerts use independent tones and volume settings. The installer includes the recommended default sounds for all three profiles.'); ?></div>
				<?php
				$missingVoices = array_filter($voices, static function ($voice) {
					return empty($voice['available']);
				});
				if (!empty($missingVoices)) { ?>
					<div class="alert alert-warning">
						<?php echo _('One or more Piper voice files are not present yet. The installer attempts to download them during install; if TTS fails, check internet access and rerun module install or install Piper voices manually.'); ?>
					</div>
				<?php } ?>
				<?php $audioProfiles = [
					[
						'title' => _('Regular Paging'), 'icon' => 'fa-bullhorn text-primary',
						'integration' => 'general',
						'opening_field' => 'opening_tone', 'closing_field' => 'closing_tone',
						'opening_default' => 'opening_Paging_Tone_Opening', 'closing_default' => 'closing_Paging_Tone_Closing',
						'volume_field' => 'announcement_tts_volume', 'volume_default' => 25,
						'voice_field' => 'announcement_piper_voice', 'voice_label' => _('Announcement Voice'), 'voice_default' => 'en_US-lessac-low.onnx',
						'help' => _('Bundled paging opening and closing tones; volume applies to tones and spoken announcements.'),
					],
					[
						'title' => _('Weather Alerts'), 'icon' => 'fa-cloud text-info',
						'integration' => 'weather',
						'opening_field' => 'nws_opening_tone', 'closing_field' => 'nws_closing_tone',
						'opening_default' => 'opening_NWS_alert', 'closing_default' => '',
						'volume_field' => 'nws_tts_volume', 'volume_default' => 25,
						'voice_field' => 'nws_piper_voice', 'voice_label' => _('Weather Voice'), 'voice_default' => 'en_US-amy-low.onnx',
						'help' => _('Bundled NWS_alert.wav opening tone with no closing tone by default.'),
					],
				]; ?>
				<div class="row">
				<?php foreach ($audioProfiles as $profile) { ?>
					<div class="col-md-6" data-sls-setup-integration="<?php echo htmlspecialchars($profile['integration']); ?>" <?php echo $profile['integration'] === 'weather' && !$weatherSetupEnabled ? 'hidden' : ''; ?>><div class="panel panel-default"><div class="panel-heading"><strong><i class="fa <?php echo $profile['icon']; ?>" aria-hidden="true"></i> <?php echo $profile['title']; ?></strong></div><div class="panel-body">
						<p class="text-muted"><?php echo $profile['help']; ?></p>
						<div class="row">
						<?php foreach (['opening' => _('Opening Tone'), 'closing' => _('Closing Tone')] as $side => $label) { $field = $profile[$side . '_field']; $defaultTone = $profile[$side . '_default']; $selectedTone = (string)($settings[$field] ?? $defaultTone); ?>
							<div class="col-sm-6"><div class="form-group"><label><?php echo $label; ?></label><select class="form-control" name="<?php echo htmlspecialchars($field); ?>"><option value="" <?php echo $selectedTone === '' ? 'selected' : ''; ?>><?php echo _('None'); ?></option><optgroup label="<?php echo htmlspecialchars(_('Mass Notify tones')); ?>"><?php foreach ($setupTones as $tone) { ?><option value="<?php echo htmlspecialchars($tone); ?>" <?php echo $selectedTone === $tone ? 'selected' : ''; ?>><?php echo htmlspecialchars(str_replace('_', ' ', $tone) . ($tone === $defaultTone ? ' (' . _('default') . ')' : '')); ?></option><?php } ?></optgroup><?php if ($setupSystemSounds) { ?><optgroup label="<?php echo htmlspecialchars(_('FreePBX System Recordings')); ?>"><?php foreach ($setupSystemSounds as $sound) { ?><option value="<?php echo htmlspecialchars($sound['value']); ?>"><?php echo htmlspecialchars($sound['label']); ?></option><?php } ?></optgroup><?php } ?></select></div></div>
						<?php } ?>
						</div>
						<div class="row"><div class="col-sm-7"><div class="form-group"><label><?php echo $profile['voice_label']; ?></label><select class="form-control" name="<?php echo htmlspecialchars($profile['voice_field']); ?>" aria-label="<?php echo htmlspecialchars($profile['voice_label'], ENT_QUOTES, 'UTF-8'); ?>"><?php foreach ($voices as $voice) { ?><option value="<?php echo htmlspecialchars($voice['path']); ?>" <?php echo (($settings[$profile['voice_field']] ?? '') === $voice['path']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($voice['name'] . (basename($voice['path']) === $profile['voice_default'] ? ' (' . _('default') . ')' : '')); ?></option><?php } ?></select></div></div><div class="col-sm-5"><div class="form-group"><label><?php echo _('Volume'); ?></label><div class="input-group"><input class="form-control" name="<?php echo htmlspecialchars($profile['volume_field']); ?>" aria-label="<?php echo htmlspecialchars($profile['title'] . ' - ' . _('Volume'), ENT_QUOTES, 'UTF-8'); ?>" type="number" min="1" max="200" value="<?php echo (int)($settings[$profile['volume_field']] ?? $profile['volume_default']); ?>"><span class="input-group-addon">%</span></div></div></div></div>
					</div></div></div>
				<?php } ?>
				</div>
				<div class="row">
					<div class="col-md-6">
						<label><?php echo _('TTS Max Seconds'); ?></label>
						<input class="form-control" name="tts_max_seconds" aria-label="<?php echo htmlspecialchars(_('TTS Max Seconds'), ENT_QUOTES, 'UTF-8'); ?>" type="number" min="1" max="600" value="<?php echo (int)($settings['tts_max_seconds'] ?? 30); ?>">
						<p class="help-block"><?php echo _('Speech longer than this limit is rejected with its measured duration. It is never silently cut short.'); ?></p>
					</div>
					<div class="col-md-6">
						<label><?php echo _('Notification Log Retention Days'); ?></label>
						<input class="form-control" name="log_retention_days" aria-label="<?php echo htmlspecialchars(_('Notification Log Retention Days'), ENT_QUOTES, 'UTF-8'); ?>" type="number" min="1" max="365" value="<?php echo (int)($settings['log_retention_days'] ?? 90); ?>">
					</div>
				</div>
				<section class="sls-setup-section" aria-labelledby="sls-setup-capacity-title">
					<div class="form-group"><label for="sls-setup-timezone"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo _('PBX timezone'); ?></label>
					<select class="form-control" id="sls-setup-timezone" name="pbx_timezone">
					<?php $selectedTimezone = ($settings['pbx_timezone'] ?? '') ?: ($pbx_timezone ?? date_default_timezone_get()); foreach (\DateTimeZone::listIdentifiers(\DateTimeZone::ALL_WITH_BC) as $zone) { ?><option value="<?php echo htmlspecialchars($zone, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $zone === $selectedTimezone ? 'selected' : ''; ?>><?php echo htmlspecialchars($zone, ENT_QUOTES, 'UTF-8'); ?></option><?php } ?>
					</select><p class="help-block"><?php echo _('A timezone change is applied by protected maintenance when notifications are idle. Review scheduled times and quiet hours after changing it.'); ?></p></div>
					<h3 id="sls-setup-capacity-title"><i class="fa fa-server text-primary" aria-hidden="true"></i> <?php echo _('Device capacity'); ?></h3>
					<p class="help-block"><?php echo _('New installations start with 25 desktops and 25 simultaneous phone contacts. Increasing either limit requires sufficient CPU, RAM and dedicated SLS free space; setup rejects increases the PBX cannot support. An extension with multiple registered phones uses multiple phone slots.'); ?></p>
					<div class="row">
						<div class="col-sm-6 form-group"><label for="sls-setup-desktop-capacity"><?php echo _('Desktop capacity'); ?></label><input id="sls-setup-desktop-capacity" class="form-control" name="desktop_client_limit" type="number" min="1" max="1000" step="1" required value="<?php echo (int)($settings['desktop_client_limit'] ?? 25); ?>"></div>
						<div class="col-sm-6 form-group"><label for="sls-setup-phone-capacity"><?php echo _('Simultaneous phone contacts'); ?></label><input id="sls-setup-phone-capacity" class="form-control" name="phone_device_limit" type="number" min="1" max="1000" step="1" required value="<?php echo (int)($settings['phone_device_limit'] ?? 25); ?>"></div>
						<p class="help-block col-sm-12"><?php echo _('On a new installation, phone capacity starts at 25 or the detected internal phone count rounded up to the next 50, whichever is higher. You can adjust it here; increases require sufficient resources.'); ?></p>
					</div>
				</section>
				<section class="sls-setup-section" aria-labelledby="sls-setup-next-title">
					<h3 id="sls-setup-next-title"><i class="fa fa-sliders text-primary" aria-hidden="true"></i> <?php echo _('After setup'); ?></h3>
					<div class="row">
						<div class="col-sm-6"><h4><i class="fa fa-phone" aria-hidden="true"></i> <?php echo _('Dial-in paging'); ?> <?php include __DIR__ . '/labs.php'; ?></h4><p><?php echo _('Use the Paging tab to configure one dial-in extension and up to ten groups, each with authorized internal callers, recipients, saved phone text and its own PIN. New group PINs are randomly generated and required by default. Optional external IVR access requires each group’s approved caller-number list and always requires its PIN. Save group stores the configuration; Apply Config prepares speech and activates the menu.'); ?></p></div>
						<div class="col-sm-6"><h4><i class="fa fa-address-book-o" aria-hidden="true"></i> <?php echo _('Recipients and integrations'); ?></h4><p><?php echo _('Locations and Audiences manages saved external phone, email and SMS recipients and device groups. General Settings manages desktop credentials, providers, webhook destinations and API permissions in categorized sections. External calling uses configured FreePBX routes or a selected trunk. Email uses the PBX mail service. SMS needs a configured Twilio, Telnyx or BulkVS account, recipient consent and sending limits. Enable and test each service before relying on it.'); ?></p></div>
						<div class="col-sm-6"><h4><i class="fa fa-shield" aria-hidden="true"></i> <?php echo _('Operators and triggers'); ?> <?php include __DIR__ . '/labs.php'; ?></h4><p><?php echo _('Operator Access manages scoped PBX roles and dedicated portal accounts with passwords and authenticators. The separate portal is disabled until an administrator enables it. Operators can send permitted alerts, manage schedules and record roll call. Triggers and Actions connects authorized panic sources, emergency-call observations, signed sensors and trusted CAP feeds to reviewed messages or actions. New integrations start disabled.'); ?></p></div>
						<div class="col-sm-6"><h4><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo _('Schedules and incidents'); ?></h4><p><?php echo _('Scheduling manages one-time, repeating and weekday calendars with holidays, late starts and reviewed date imports. General Settings includes deployment readiness checks. Incidents manages templates, updates, all-clear and operator roll call. A desktop receipt confirms software delivery; it does not mean a person read or acknowledged the message. Incident templates also support reviewed resource links and manually reviewed language variants. Reviewed English, Spanish, French, German and Portuguese variants can use matching installed speech voices.'); ?></p></div>
						<div class="col-sm-6"><h4><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo _('Locations and audiences'); ?></h4><p><?php echo _('After setup, organize saved recipients into sites, buildings, floors and rooms. Review a location’s audience or add reviewed coordinates and select a geographic area. Missing and stale positions are listed before saving. Apply Config to activate the group. Location edits do not change existing groups or queued alerts.'); ?></p></div>
						<div class="col-sm-6"><h4><i class="fa fa-shield" aria-hidden="true"></i> <?php echo _('Maintenance and media access'); ?></h4><p><?php echo _('General Settings provides encrypted configuration exports, signed update policy, and optional network restrictions and download expiry for generated phone images and XML. Media restrictions and automatic installation are off by default. Check deployment readiness and perform a limited recipient test after setup.'); ?></p></div>
					</div>
				</section>
				<input type="hidden" name="sls_setup_form_complete" value="1">
				<hr>
				<button type="submit" class="btn btn-primary"><?php echo _('Complete Setup'); ?></button>
			</form>
		</div>
	</div>
</div>
</div>
</div>
<script>
(function() {
	var addressToggle = document.getElementById('sls-setup-address-change');
	var addressPorts = document.getElementById('sls-setup-ports');
	var addressHost = document.getElementById('sls-setup-host');
	var addressPreview = document.getElementById('sls-setup-address-preview');
	var setupForm = addressHost && addressHost.form;
	var imageScheme = setupForm && setupForm.querySelector('[name="sipnotify_media_scheme"]');
	var savedPreview = addressPreview ? addressPreview.textContent : '';
	function renderSetupAddress() {
		if (!addressToggle || !addressPorts || !addressHost || !addressPreview) { return; }
		var enabled = addressToggle.checked;
		addressHost.disabled = !enabled;
		addressHost.required = enabled;
		addressPorts.disabled = !enabled;
		addressPorts.hidden = !enabled;
		addressToggle.setAttribute('aria-expanded', enabled ? 'true' : 'false');
		if (!enabled) { addressPreview.textContent = savedPreview; return; }
		function address(kind, scheme, path) {
			var port = document.getElementById('sls-setup-port-' + kind).value;
			return scheme + '://' + addressHost.value.trim().toLowerCase() + (port === (scheme === 'https' ? '443' : '80') ? '' : ':' + port) + path;
		}
		addressPreview.textContent = <?php echo json_encode(_('Desktop API:')); ?> + ' ' + address('api', 'https', '/api/sipnotify')
			+ '\n' + <?php echo json_encode(_('Control API:')); ?> + ' ' + address('control', 'https', '/api/sls-mass-notify')
			+ '\n' + <?php echo json_encode(_('Phone images:')); ?> + ' ' + address('media', imageScheme ? imageScheme.value : 'http', '/sls_mass_notify');
	}
	if (setupForm) {
		setupForm.addEventListener('input', renderSetupAddress);
		setupForm.addEventListener('change', renderSetupAddress);
	}
	renderSetupAddress();
	var weatherSelect = document.getElementById('sls-setup-weather-enabled');
	var weatherDetails = document.getElementById('sls-setup-weather-details');
	var lightningSelect = document.getElementById('sls-setup-lightning-enabled');
	var lightningDetails = document.getElementById('sls-setup-lightning-details');
	var adaptive = document.getElementById('sls-setup-adaptive');
	var card = document.getElementById('sls-setup-adaptive-card');
	var shield = document.getElementById('sls-setup-adaptive-shield');
	var label = document.getElementById('sls-setup-adaptive-label');
	var zone = document.getElementById('sls-setup-adaptive-zone');
	function setFieldsEnabled(root, enabled) {
		if (!root) { return; }
		Array.prototype.forEach.call(root.querySelectorAll('input, select, textarea, button'), function(field) {
			field.disabled = !enabled || field.getAttribute('data-sls-permanent-disabled') === '1';
		});
	}
	function renderOptionalSection(select, details) {
		if (!select || !details) { return false; }
		var enabled = select.value === '1';
		details.hidden = !enabled;
		select.setAttribute('aria-expanded', enabled ? 'true' : 'false');
		setFieldsEnabled(details, enabled);
		return enabled;
	}
	function renderWeatherState() {
		var enabled = renderOptionalSection(weatherSelect, weatherDetails);
		Array.prototype.forEach.call(document.querySelectorAll('[data-sls-setup-integration="weather"]'), function(profile) {
			profile.hidden = !enabled;
			setFieldsEnabled(profile, enabled);
		});
	}
	function renderAdaptiveState() {
		if (!adaptive || !card) { return; }
		var enabled = !!(lightningSelect && lightningSelect.value === '1' && adaptive.checked);
		card.classList.toggle('is-enabled', enabled);
		card.classList.toggle('is-disabled', !enabled);
		if (shield) { shield.className = 'fa fa-shield ' + (enabled ? 'text-success' : 'text-danger'); }
		if (label) { label.textContent = enabled ? <?php echo json_encode(_('Adaptive protection enabled')); ?> : <?php echo json_encode(_('Adaptive protection disabled')); ?>; }
		// The server selects the first newly configured Weather zone when this is blank.
		if (zone) { zone.required = false; }
	}
	function renderLightningState() {
		renderOptionalSection(lightningSelect, lightningDetails);
		renderAdaptiveState();
	}
	if (weatherSelect) { weatherSelect.addEventListener('change', renderWeatherState); }
	if (lightningSelect) { lightningSelect.addEventListener('change', renderLightningState); }
	if (adaptive) {
		adaptive.addEventListener('change', renderAdaptiveState);
	}
	renderWeatherState();
	renderLightningState();
}());
</script>
<?php if ($dismissible) { ?>
<script>
(function() {
	var dismiss = document.querySelector('.sls-setup-dismiss');
	if (!dismiss) {
		return;
	}
	dismiss.addEventListener('click', function() {
		var backdrop = document.querySelector('.sls-setup-backdrop');
		var shell = document.querySelector('.sls-setup-modal-shell');
		if (backdrop) {
			backdrop.style.display = 'none';
		}
		if (shell) {
			shell.style.display = 'none';
		}
	});
}());
</script>
<?php } ?>

<script>(function(){var select=document.getElementById("sls-setup-lightning-provider");if(select)select.addEventListener("change",function(){this.closest("form").querySelectorAll('[name="xweather[client_id]"],[name="xweather[client_secret]"]').forEach(function(input){input.value="";});});})();</script>

<script>
(function(){
    var provider=document.getElementById('sls-setup-lightning-provider');
    var period=document.querySelector('[name="xweather[query_interval_minutes]"]');
    if(!provider||!period)return;
    function limits(){
        var maximum=provider.value==='xweather'?4:10;
        Array.from(period.options).forEach(function(option){option.disabled=Number(option.value)>maximum;option.hidden=option.disabled;});
        if(Number(period.value)>maximum)period.value=String(maximum);
    }
    provider.addEventListener('change',limits);limits();
})();
</script>
