<?php
namespace FreePBX\modules;
require_once __DIR__ . '/DeviceAcceptance.php';

/** A small allowlisted report, never a dump of configuration or raw logs. */
trait SlsSupportDiagnostics
{
    private function mayIncludeDeviceAcceptance(array $settings): bool
    {
        $principal = $GLOBALS['sls_control_principal'] ?? null;
        // Trusted local tools already run with protected configuration access.
        if (PHP_SAPI === 'cli' && !isset($_SESSION['AMP_user']) && $principal === null) { return true; }
        if ($principal !== null) {
            if (!is_array($principal) || isset($principal['operator_role']) || ($principal['id'] ?? '') === 'legacy') { return false; }
            $current = \SLS\MassNotify\ApiSecurity::currentCredential($settings, $principal['id'] ?? '');
            return is_array($current) && in_array('read', $current['scopes'] ?? [], true)
                && ($current['audience']['unrestricted'] ?? false) === true;
        }
        try { return ($this->currentOperator()['operator_role'] ?? '') === 'administrator'; }
        catch (\Throwable $error) { return false; }
    }

    public function getDeploymentReadiness(): array
    {
        require_once __DIR__ . '/DeploymentReadiness.php';
        $now = time(); $checks = []; $settings = $this->getActiveSettings();
        require_once __DIR__.'/api/sls-mass-notify/runtime-security.php';
        $phpSecurity = \SLS\MassNotify\PhpSecurityPolicy::evaluate(PHP_VERSION);
        $checks[] = SlsDeploymentReadiness::check('php_security', _('PHP security updates'), $phpSecurity['ok'] ? 'ok' : 'warning',
            $phpSecurity['ok'] ? sprintf(_('PHP %s meets the reviewed security floor.'), PHP_VERSION)
                : ($phpSecurity['minimum'] !== ''
                    ? sprintf(_('PHP %s requires %s or a newer security update on the same branch. Update through trusted vendor packages and reload the affected PHP workers.'), PHP_VERSION, $phpSecurity['minimum'])
                    : _('This PHP build needs independent vendor security review; it is outside the reviewed policy.')));
        // Monitoring does not need a live AMI device scan. Existing diagnostics
        // and bounded snapshots remain useful when maintenance has stopped.
        $summary = $this->getDiagnosticsSummary(false);
        foreach (array_slice((array)($summary['checks'] ?? []), 0, 64) as $index => $check) {
            if (!is_array($check)) { continue; }
            $runtimeCheck = SlsDeploymentReadiness::check('runtime_' . $index, (string)($check['label'] ?? ''),
                ($check['ok'] ?? false) === true ? 'ok' : 'warning', (string)($check['detail'] ?? ''));
            $runtimeCheck['code'] = SlsDeploymentReadiness::runtimeCode($check);
            $checks[] = $runtimeCheck;
        }
        $storage = SlsDeploymentReadiness::snapshot(self::PLUGIN_DATA_DIR . '/storage-summary.json');
        $checks[] = SlsDeploymentReadiness::heartbeat('maintenance', _('Maintenance heartbeat'), $storage, 300, $now);
        $checks = array_merge($checks, SlsDeploymentReadiness::audit($storage, ($settings['control_api']['audit_syslog'] ?? '0') === '1'));
        $checks[] = SlsDeploymentReadiness::heartbeat('worker_probe', _('Announcement worker heartbeat'),
            SlsDeploymentReadiness::snapshot(self::PLUGIN_DATA_DIR . '/announcement-jobs/worker-probe.json'), 600, $now);
        $checks[] = SlsDeploymentReadiness::clock();
        $checks[] = SlsDeploymentReadiness::certificate(SlsAdvertisedAddress::checkLocalHttps($settings), $now);
        $media = SlsLocalWebProbe::mediaAccess($settings);
        $checks[] = SlsDeploymentReadiness::check('media_access', _('Generated-media access'), $media['ok'] ? 'ok' : 'warning', $media['message']);
        $capacity = $this->checkDesktopCapacityResources((int)($settings['desktop_client_limit'] ?? 25), (int)($settings['phone_device_limit'] ?? 25));
        $checks[] = SlsDeploymentReadiness::capacity($capacity);
        $checks = array_merge($checks, $this->automationDependencyChecks($settings));
        $attention = count(array_filter($checks, static function ($check) { return $check['state'] === 'warning'; }));
        $unknown = count(array_filter($checks, static function ($check) { return $check['state'] === 'unknown'; }));
        $report = ['schema'=>'sls-deployment-readiness-v1', 'check_schema_version'=>2, 'generated_at'=>gmdate('c'), 'version'=>self::MODULE_VERSION,
            'operational_ready'=>$attention === 0 && $unknown === 0,
            'attention_count'=>$attention, 'unknown_count'=>$unknown, 'checks'=>$checks,
            'verification_scope'=>_('Read-only local PBX checks. Test the advertised address from a desktop to verify external routing. Handset display, complete audio playback and enabled provider delivery need separate device or provider acceptance tests.')];
        if ($this->mayIncludeDeviceAcceptance($settings)) {
            $stored = $this->deviceAcceptanceConfiguration(self::SETTINGS_JSON);
            $report['device_acceptance'] = \SLS\MassNotify\DeviceAcceptance::report($stored['settings'], self::MODULE_VERSION);
        }
        return $report;
    }

    public function getRedactedSupportDiagnostics()
    {
        $version = static function ($value) {
            return is_string($value) && preg_match('/^[0-9][0-9A-Za-z.+_-]{0,63}$/D', $value) ? $value : 'unavailable';
        };
        $report = [
            'schema' => 'sls-redacted-diagnostics-v1', 'generated_at' => gmdate('c'),
            'versions' => ['slsmassnotifyserver' => self::MODULE_VERSION, 'php' => $version(PHP_VERSION)],
            'timezone' => in_array(date_default_timezone_get(), \DateTimeZone::listIdentifiers(\DateTimeZone::ALL_WITH_BC), true) ? date_default_timezone_get() : 'unavailable',
            'checks' => [], 'permissions' => [], 'devices' => ['available' => false, 'count' => 0, 'formats' => [], 'transports' => []],
            'queue_counts' => [],
            'excluded' => ['configuration', 'credentials', 'addresses', 'hostnames', 'device_identifiers', 'message_contents', 'raw_logs'],
        ];
        $build=\SLS\MassNotify\DeviceAcceptance::buildIdentity();
        if ($build!==null) {
            $report['build']=['version'=>$build['module_version'],'inventory_sha256'=>$build['inventory_sha256']];
        }
        try {
            $query = $this->FreePBX->Database()->prepare('SELECT version FROM modules WHERE modulename = ? LIMIT 1');
            foreach (['framework', 'dashboard', 'backup', 'recordings'] as $module) {
                $query->execute([$module]);
                $report['versions'][$module] = $version($query->fetchColumn());
            }
        } catch (\Throwable $error) { $report['versions']['freepbx_inventory'] = 'unavailable'; }
        $os = @file_get_contents('/etc/os-release', false, null, 0, 8192);
        if (is_string($os) && preg_match('/^VERSION_ID="?([0-9.]+)"?$/m', $os, $match)) {
            $report['versions']['os_version_id'] = $version($match[1]);
        }
        // Only these static labels can appear; diagnostic details may contain
        // settings or paths and must never be copied into the downloadable file.
        $labels = ['Central config', 'Central config loader', 'SIP NOTIFY sender', 'NWS poller',
            'Weather scheduler', 'Weather delivery worker', 'Announcement scheduler', 'General announcement worker', 'Phone admission and outcome collector', 'Xweather poller',
            'Branded email sender', 'Branded Discord sender', 'Notification destination dispatcher',
            'System/error email notifier', 'Weather zone status helper', 'Weather cross-zone delivery coordinator',
            'Maintenance worker', 'Piper binary', 'Executable runtime ownership', 'Piper voice',
            'Notification log', 'Desktop journal', 'Local email transport', 'Postfix service and queue', 'Storage and delivery monitor', 'Control API',
            'Storage free-space measurement', 'External delivery queue', 'Weather delivery queue'];
        try {
            $summary = $this->getDiagnosticsSummary();
            $checks = $summary['checks'] ?? [];
            if (is_array($summary['announcement_worker'] ?? null)) {
                $worker = $summary['announcement_worker'];
                $safe = [];
                foreach (['ok', 'worker_exists', 'php_cli_exists', 'storage_writable', 'bootstrap_ok', 'probe_fresh'] as $key) {
                    $safe[$key] = ($worker[$key] ?? null) === true;
                }
                $safe['latest_state'] = in_array($worker['latest_state'] ?? '', ['idle', 'queued', 'worker_starting', 'running', 'complete', 'failed', 'cancelled', 'expired'], true) ? $worker['latest_state'] : 'unavailable';
                $safe['failure_category'] = in_array($worker['failure_category'] ?? '', ['worker_start_failed', 'worker_bootstrap_failed',
                    'worker_module_load_failed', 'worker_runtime_failed', 'worker_timeout', 'audio_submission_failed',
                    'sip_notify_submission_failed', 'channel_submission_failed', 'announcement_activity_timeout', 'job_expired',
                    'weather_source_cancelled'], true) ? $worker['failure_category'] : '';
                $report['announcement_worker'] = $safe;
            }
            foreach ($labels as $label) {
                foreach ($checks as $check) {
                    if (is_array($check) && ($check['label'] ?? '') === _($label)) {
                        $report['checks'][] = ['check' => $label, 'ok' => ($check['ok'] ?? null) === true];
                        break;
                    }
                }
            }
        } catch (\Throwable $error) { $report['checks_available'] = false; }
        foreach (['central_config' => self::SETTINGS_JSON, 'runtime' => self::RUNTIME_DIR,
            'announcement_worker' => self::RUNTIME_DIR . '/sls_mass_notify_announcement_worker.php',
            'audio_queue' => self::RUNTIME_DIR . '/sls_audio_queue.py',
            'piper' => self::PIPER_BIN, 'generated_audio' => self::TTS_DIR] as $name => $path) {
            $metadata = @lstat($path);
            $report['permissions'][$name] = $metadata === false ? ['exists' => false] : [
                'exists' => true, 'mode' => sprintf('%04o', $metadata['mode'] & 0777),
                'root_owned' => $metadata['uid'] === 0, 'symbolic_link' => ($metadata['mode'] & 0170000) === 0120000,
                'readable' => is_readable($path), 'executable' => is_executable($path),
            ];
        }
        try {
            $inventory = $this->getDeviceOverrideInventory();
            $report['devices']['available'] = ($inventory['success'] ?? false) === true;
            foreach (array_slice($inventory['devices'] ?? [], 0, 1000) as $device) {
                if (!is_array($device)) { continue; }
                $report['devices']['count']++;
                $format = $device['format'] ?? 'unknown';
                if (!in_array($format, ['yealink', 'yealink_text', 'yealink_image', 'cisco', 'poly', 'polycom', 'grandstream', 'fanvil', 'snom', 'aastra', 'mitel', 'sangoma', 'avaya', 'vtech', 'ale', 'alcatel', 'panasonic'], true)) { $format = 'unknown'; }
                $transport = strtolower(is_string($device['transport'] ?? null) ? $device['transport'] : 'unknown');
                if (!in_array($transport, ['udp', 'tcp', 'tls'], true)) { $transport = 'unknown'; }
                foreach (['formats' => $format, 'transports' => $transport] as $field => $key) {
                    $report['devices'][$field][$key] = ($report['devices'][$field][$key] ?? 0) + 1;
                }
            }
        } catch (\Throwable $error) { $report['devices']['available'] = false; }
        try {
            $summary = $this->loadJsonFile(self::PLUGIN_DATA_DIR . '/storage-summary.json');
            foreach (['pending_external', 'expired_external', 'queue_errors', 'queue_files_scanned', 'queue_files_seen', 'audit_failed_records', 'pending_weather', 'failed_weather', 'uncertain_weather', 'expired_weather', 'weather_running', 'weather_max_workers', 'weather_oldest_queued_age_seconds', 'weather_oldest_running_age_seconds', 'weather_deadline_misses'] as $key) {
                $value = $summary[$key] ?? null;
                $report['queue_counts'][$key] = is_int($value) && $value >= 0 && $value <= 1000000 ? $value : null;
            }
            $report['queue_scan_incomplete'] = ($summary['queue_scan_incomplete'] ?? false) === true;
            $report['retained_components'] = [];
            foreach (['configuration','configuration_backups','announcement_jobs','desktop_journal','phone_evidence','weather_evidence','incident_evidence','sms_evidence','enterprise_evidence','floorplan_images','other_state'] as $name) {
                $row=$summary['retained_components'][$name] ?? [];
                $report['retained_components'][$name]=[
                    'bytes'=>is_int($row['bytes']??null)&&$row['bytes']>=0 ? $row['bytes'] : null,
                    'files'=>is_int($row['files']??null)&&$row['files']>=0 ? $row['files'] : null,
                    'complete'=>($row['complete']??false)===true];
            }
        } catch (\Throwable $error) { $report['queue_counts_available'] = false; }
        require_once __DIR__.'/Monitoring.php';
        $snapshot=SlsDeploymentReadiness::snapshot(self::PLUGIN_DATA_DIR.'/support-snapshot.json');
        $report['runtime_environment']=\SLS\MassNotify\Monitoring::report($snapshot);
        $recovery=$snapshot['data']['installer_transactions']??[];
        $report['installer_recovery']=['complete'=>($recovery['complete']??false)===true,'counts'=>[]];
        foreach(['preparing','prepared','mutating','recovering','recovery_failed','committed','rolled_back','abandoned'] as $phase){
            $value=$recovery['counts'][$phase]??null;
            if(is_int($value)&&$value>=0&&$value<=256){$report['installer_recovery']['counts'][$phase]=$value;}
        }
        return $report;
    }
}
