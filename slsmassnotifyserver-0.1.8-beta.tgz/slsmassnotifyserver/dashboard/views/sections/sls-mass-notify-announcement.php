<?php
$announcementTargets = is_array($announcement_targets ?? null) ? $announcement_targets : [];
$announcementGroupTargets = is_array($announcement_group_targets ?? null) ? $announcement_group_targets : $announcementTargets;
$desktopClients = is_array($announcement_desktop_clients ?? null) ? $announcement_desktop_clients : [];
$voiceRecipients = is_array($outbound_voice_recipients ?? null) ? $outbound_voice_recipients : [];
$emailRecipients = array_map(static function ($row) { return ['id' => (string)($row['id'] ?? ''), 'name' => (string)($row['name'] ?? '')]; }, array_values(array_filter((array)($announcement_email_recipients ?? []), 'is_array')));
$smsRecipients = array_map(static function ($row) { return ['id' => (string)($row['id'] ?? ''), 'name' => (string)($row['name'] ?? '')]; }, array_values(array_filter((array)($announcement_sms_recipients ?? []), 'is_array')));
$recipientSelectionView = $recipient_selection_view ?? dirname(__DIR__, 3) . '/views/recipient_selection.php';
$announcementWebhooks = is_array($announcement_webhooks ?? null) ? $announcement_webhooks : [];
$announcementGroups = is_array($announcement_groups ?? null) ? $announcement_groups : [];
$announcementCooldown = (int)($announcement_cooldown_remaining ?? 0);
$announcementState = is_array($announcement_state ?? null) ? $announcement_state : [];
$announcementTones = is_array($announcement_tones ?? null) ? $announcement_tones : [];
$quietHoursActive = !empty($announcementState['quiet_hours_active']);
$setupComplete = !empty($setup_complete);
$setupModal = (string)($setup_modal ?? '');
$csrfToken = (string)($csrf_token ?? '');
$enabledDesktopCount = 0;
foreach ($desktopClients as $desktopClient) {
	if (!empty($desktopClient['enabled'])) {
		$enabledDesktopCount++;
	}
}
?>
<style>
#dashboard-sls-mass-notify-announcement {
	padding: 5px 7px 10px;
	color: #1f2937;
	box-sizing: border-box;
	max-width: 100%;
	min-width: 0;
	overflow: visible;
	overflow-wrap: anywhere;
}
#dashboard-sls-mass-notify-announcement form,
#dashboard-sls-mass-notify-announcement .sls-step-card,
#dashboard-sls-mass-notify-announcement .sls-color-designer,
#dashboard-sls-mass-notify-announcement .sls-destination-grid,
#dashboard-sls-mass-notify-announcement .sls-destination-panel { max-width: 100%; min-width: 0; box-sizing: border-box; }
#dashboard-sls-mass-notify-announcement .sls-widget-intro {
	margin: 0 0 10px;
	color: #64748b;
	font-size: 13px;
}
#dashboard-sls-mass-notify-announcement .sls-step-card {
	margin: 0 0 10px;
	padding: 12px;
	border: 1px solid #dfe5ec;
	border-radius: 9px;
	background: #fff;
	box-shadow: 0 2px 6px rgba(15, 23, 42, .045);
}
#dashboard-sls-mass-notify-announcement .sls-step-heading {
	display: flex;
	align-items: center;
	gap: 8px;
	margin: 0 0 9px;
	font-size: 15px;
	font-weight: 700;
}
#dashboard-sls-mass-notify-announcement .sls-step-number {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	width: 23px;
	height: 23px;
	flex: 0 0 23px;
	border-radius: 50%;
	color: #fff;
	background: #6d28d9;
	font-size: 12px;
}
#dashboard-sls-mass-notify-announcement .sls-step-subtitle {
	margin: -4px 0 10px 31px;
	color: #64748b;
	font-size: 12px;
}
#dashboard-sls-mass-notify-announcement .sls-groups-toolbar {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 10px;
	min-width: 0;
}
#dashboard-sls-mass-notify-announcement .sls-groups-toolbar > label {
	margin: 0;
}
#dashboard-sls-mass-notify-announcement .sls-group-list {
	margin: 7px 0 9px;
	padding: 8px 10px;
	border: 1px solid #e5e7eb;
	border-radius: 7px;
	background: #f8fafc;
	max-height: 116px;
	overflow: auto;
}
#dashboard-sls-mass-notify-announcement .sls-group-list .checkbox {
	display: flex;
	align-items: flex-start;
	gap: 3px;
	margin: 0 0 5px;
	min-width: 0;
}
#dashboard-sls-mass-notify-announcement .sls-group-list .checkbox:last-child { margin-bottom: 0; }
#dashboard-sls-mass-notify-announcement .sls-group-list .checkbox > label {
	flex: 1 1 auto;
	min-width: 0;
	overflow-wrap: anywhere;
}
#dashboard-sls-mass-notify-announcement .sls-group-list .btn-link {
	flex: 0 0 auto;
	padding: 1px 4px;
}
#dashboard-sls-mass-notify-announcement .sls-destination-grid {
	display: grid;
	grid-template-columns: repeat(auto-fit, minmax(165px, 1fr));
	gap: 8px;
}
#dashboard-sls-mass-notify-announcement .sls-destination-panel {
	align-self: start;
	border: 1px solid #dfe5ec;
	border-radius: 7px;
	background: #f8fafc;
	overflow: hidden;
}
#dashboard-sls-mass-notify-announcement .sls-destination-panel[open] {
	background: #fff;
	box-shadow: 0 1px 4px rgba(15, 23, 42, .05);
}
#dashboard-sls-mass-notify-announcement .sls-destination-panel summary {
	display: flex;
	align-items: center;
	gap: 7px;
	min-width: 0;
	padding: 9px 10px;
	font-weight: 600;
	cursor: pointer;
	list-style: none;
	user-select: none;
}
#dashboard-sls-mass-notify-announcement .sls-destination-panel summary::-webkit-details-marker { display: none; }
#dashboard-sls-mass-notify-announcement .sls-destination-panel summary:focus {
	outline: 2px solid #8b5cf6;
	outline-offset: -2px;
}
#dashboard-sls-mass-notify-announcement .sls-destination-panel summary .fa:first-child {
	width: 15px;
	color: #6d28d9;
	text-align: center;
}
#dashboard-sls-mass-notify-announcement .sls-destination-panel summary .sls-destination-label {
	flex: 1 1 auto;
	min-width: 0;
}
#dashboard-sls-mass-notify-announcement .sls-destination-count {
	padding: 1px 7px;
	border-radius: 999px;
	background: #e9e4f7;
	color: #4c1d95;
	font-size: 11px;
	font-weight: 700;
}
#dashboard-sls-mass-notify-announcement .sls-destination-chevron {
	color: #64748b;
	transition: transform .16s ease;
}
#dashboard-sls-mass-notify-announcement .sls-destination-panel[open] .sls-destination-chevron { transform: rotate(180deg); }
#dashboard-sls-mass-notify-announcement .sls-destination-body {
	padding: 0 10px 9px;
	border-top: 1px solid #e8edf3;
}
#dashboard-sls-mass-notify-announcement .sls-destination-body > .checkbox-inline {
	display: block;
	margin: 8px 0 5px;
}
#dashboard-sls-mass-notify-announcement .sls-compact-help {
	margin: 6px 0 0;
	font-size: 12px;
}
#dashboard-sls-mass-notify-announcement .sls-action-row {
	display: flex; flex-wrap: wrap; align-items: center; gap: 12px;
	padding: 14px 0 0; border-top: 1px solid #e2e8f0;
}
#dashboard-sls-mass-notify-announcement .sls-send-button {
	flex: 0 0 auto; min-height: 38px; min-width: 175px; padding: 9px 16px;
	border-radius: 6px; font-size: 13px; font-weight: 600; line-height: 20px;
	white-space: nowrap; box-shadow: none;
}
#dashboard-sls-mass-notify-announcement .sls-send-button:focus-visible { outline: 2px solid #2563eb; outline-offset: 3px; }
#dashboard-sls-mass-notify-announcement .sls-send-button:disabled { opacity: .65; }
#dashboard-sls-mass-notify-announcement .sls-announcement-inline-status {
	display: flex; align-items: flex-start; gap: 8px; margin: 12px 0 0;
	padding: 10px 12px; border: 1px solid #e2e8f0; border-radius: 6px;
	background: #f8fafc; color: #475569; font-size: 13px; line-height: 1.5;
	overflow-wrap: anywhere;
}
#dashboard-sls-mass-notify-announcement .sls-announcement-inline-status .fa { margin-top: 3px; flex: 0 0 auto; }
#dashboard-sls-mass-notify-announcement .sls-status-success { color: #166534; background: #f0fdf4; border-color: #bbf7d0; }
#dashboard-sls-mass-notify-announcement .sls-status-warning,
#dashboard-sls-mass-notify-announcement .sls-status-danger { color: #92400e; background: #fffbeb; border-color: #fde68a; }
#dashboard-sls-mass-notify-announcement .sls-announcement-cooldown { margin: 0; font-size: 12px; color: #64748b; }
#dashboard-sls-mass-notify-announcement .sls-delivery-details { margin-top: 9px; font-size: 12px; color: #64748b; }
#dashboard-sls-mass-notify-announcement .sls-delivery-details summary { cursor: pointer; padding: 4px 0; }
#dashboard-sls-mass-notify-announcement .sls-delivery-details ul { max-height: 180px; overflow-y: auto; padding-left: 20px; margin: 8px 0; }
#dashboard-sls-mass-notify-announcement .sls-delivery-details li { padding: 3px 0; overflow-wrap: anywhere; }
#dashboard-sls-mass-notify-announcement .sls-submit-spinner { display: none; margin-right: 7px; }
#dashboard-sls-mass-notify-announcement .sls-submit-busy .sls-submit-spinner { display: inline-block; }
#dashboard-sls-mass-notify-announcement .sls-submit-busy { cursor: wait; }
#dashboard-sls-mass-notify-announcement .sls-priority-field { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin: 10px 0 12px; }
#dashboard-sls-mass-notify-announcement .sls-priority-field label { margin: 0; font-size: 12px; }
#dashboard-sls-mass-notify-announcement .sls-priority-field select { width: auto; max-width: 100%; height: 32px; padding: 4px 8px; }
#dashboard-sls-mass-notify-announcement .sls-composer-grid {
	display: grid;
	grid-template-columns: minmax(0, 1.35fr) minmax(210px, .65fr);
	gap: 11px;
	align-items: start;
}
#dashboard-sls-mass-notify-announcement .sls-option-box {
	padding: 9px 10px;
	border: 1px solid #e5e7eb;
	border-radius: 7px;
	background: #f8fafc;
}
#dashboard-sls-mass-notify-announcement .sls-option-box .form-group:last-child { margin-bottom: 0; }
#dashboard-sls-mass-notify-announcement .sls-tone-grid {
	display: grid;
	grid-template-columns: repeat(2, minmax(0, 1fr));
	gap: 8px;
	margin-top: 8px;
}
#dashboard-sls-mass-notify-announcement .sls-tone-grid > div { min-width: 0; }
#dashboard-sls-mass-notify-announcement .sls-tone-grid label { font-size: 12px; }
#dashboard-sls-mass-notify-announcement .sls-tone-grid .form-control { width: 100%; }
#dashboard-sls-mass-notify-announcement .sls-message-count {
	display: block;
	margin-top: 3px;
	text-align: right;
	color: #64748b;
	font-size: 11px;
}
#dashboard-sls-mass-notify-announcement .sls-target-list {
	max-height: 126px;
	overflow-y: auto;
	overflow-x: hidden;
	padding: 4px 4px 0 0;
	margin: 0;
}
#dashboard-sls-mass-notify-announcement .modal .sls-target-list {
	max-height: 260px;
}
#dashboard-sls-mass-notify-announcement .sls-target-list .checkbox,
#dashboard-sls-mass-notify-announcement .sls-target-list .checkbox-inline {
	display: block;
	min-height: 22px;
	margin-top: 0;
	margin-bottom: 4px;
	overflow-wrap: anywhere;
	word-break: break-word;
}
#dashboard-sls-mass-notify-announcement .sls-target-list .col-sm-4,
#dashboard-sls-mass-notify-announcement .sls-target-list .col-sm-6,
#dashboard-sls-mass-notify-announcement .sls-target-list .col-sm-12 {
	margin-bottom: 4px;
}
#dashboard-sls-mass-notify-announcement .row { max-width: calc(100% + 30px); }
#dashboard-sls-mass-notify-announcement .form-control { max-width: 100%; }
#dashboard-sls-mass-notify-announcement textarea {
	resize: vertical;
	min-height: 96px;
}
#dashboard-sls-mass-notify-announcement .sls-labs-badge {
	display: inline-block;
	margin-left: 6px;
	vertical-align: middle;
}
#dashboard-sls-mass-notify-announcement .sls-color-designer {
	display: none;
	margin: 9px 0 1px;
	padding: 10px;
	border-left: 4px solid #22c55e;
	background: #f7faf8;
}
#dashboard-sls-mass-notify-announcement .sls-color-preview {
	min-height: 112px;
	padding: 14px;
	color: #fff;
	background: #1f2937;
	border-radius: 4px;
	overflow-wrap: anywhere;
}
#dashboard-sls-mass-notify-announcement .sls-color-preview-title {
	font-size: 18px;
	font-weight: 700;
	margin-bottom: 8px;
}
#dashboard-sls-mass-notify-announcement .sls-preview-actions { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); max-width:640px; gap:8px; margin:12px 0 8px; }
#dashboard-sls-mass-notify-announcement .sls-preview-actions .btn { min-height:36px; padding:7px 12px; font-size:13px; }
#dashboard-sls-mass-notify-announcement .sls-rendered-preview { max-width:640px; padding:14px; margin:8px 0 14px; border:1px solid #d9e2eb; border-radius:6px; background:#f7f9fc; }
#dashboard-sls-mass-notify-announcement .sls-rendered-preview img { display:block; width:480px; max-width:100%; height:auto; border-radius:4px; margin:10px 0; }
#dashboard-sls-mass-notify-announcement .sls-rendered-preview audio { display:block; width:100%; max-width:480px; margin:10px 0; }
#dashboard-sls-mass-notify-announcement .sls-preview-text { white-space:pre-wrap; overflow-wrap:anywhere; margin-top:8px; }
@media (max-width: 767px) {
	#dashboard-sls-mass-notify-announcement .sls-preview-actions { grid-template-columns:repeat(2,minmax(0,1fr)); }
	#dashboard-sls-mass-notify-announcement .sls-preview-actions .btn { white-space:normal; overflow-wrap:anywhere; }
	#dashboard-sls-mass-notify-announcement .sls-destination-grid,
	#dashboard-sls-mass-notify-announcement .sls-composer-grid { grid-template-columns: minmax(0, 1fr); }
	#dashboard-sls-mass-notify-announcement .sls-action-row { align-items: stretch; flex-direction: column; }
	#dashboard-sls-mass-notify-announcement .sls-action-row .btn { width: 100%; }
	#dashboard-sls-mass-notify-announcement .sls-announcement-inline-status { flex-basis: auto; }
	#dashboard-sls-mass-notify-announcement .sls-announcement-cooldown { align-self: center; }
	#dashboard-sls-mass-notify-announcement .sls-groups-toolbar { align-items: flex-start; flex-direction: column; }
}
@media (max-width: 420px) {
	#dashboard-sls-mass-notify-announcement { padding-left: 2px; padding-right: 2px; }
	#dashboard-sls-mass-notify-announcement .sls-step-card { padding: 10px; }
	#dashboard-sls-mass-notify-announcement .sls-tone-grid { grid-template-columns: minmax(0, 1fr); }
}
</style>
<div class="container-fluid" id="dashboard-sls-mass-notify-announcement" data-quiet-hours-active="<?php echo $quietHoursActive ? '1' : '0'; ?>">
	<?php if (!$setupComplete) { ?>
		<div class="alert alert-warning">
			<strong><?php echo _('Setup Required'); ?></strong><br>
			<?php echo htmlspecialchars((string)($setup_required_message ?? _('Setup wizard must be completed before Mass Notifications can be used.'))); ?>
			<div style="margin-top: 10px;">
				<button type="button" class="btn btn-primary btn-sm" id="dashboard-sls-setup-open"><?php echo _('Open Setup Wizard'); ?></button>
			</div>
		</div>
		<?php echo $setupModal; ?>
		<script>
		(function() {
			var lifecycleKey = '__slsMassNotifyAnnouncementWidget';
			var previousLifecycle = window[lifecycleKey];
			if (previousLifecycle && typeof previousLifecycle.dispose === 'function') {
				previousLifecycle.dispose();
			}
			var open = document.getElementById('dashboard-sls-setup-open');
			if (!open) {
				return;
			}
			open.addEventListener('click', function() {
				var backdrop = document.querySelector('.sls-setup-backdrop');
				var shell = document.querySelector('.sls-setup-modal-shell');
				if (backdrop) {
					backdrop.style.display = '';
				}
				if (shell) {
					shell.style.display = '';
				}
			});
		}());
		</script>
	</div>
	<?php return; ?>
	<?php } ?>
	<div id="dashboard-sls-mass-notify-group-result" role="status" aria-live="polite" style="display: none;"></div>
	<p class="sls-widget-intro"><?php echo _('Choose destinations, write the message, and select how it should be delivered.'); ?></p>
	<form id="dashboard-sls-mass-notify-announcement-form" method="post" action="config.php?display=slsmassnotifyserver">
		<?php $recipient_selection_form_id = 'dashboard-sls-mass-notify-announcement-form'; $recipient_selection_keys = ['announcement_extensions', 'announcement_groups', 'announcement_desktop_clients', 'announcement_webhooks', 'voice_recipient_ids', 'announcement_email_recipient_ids', 'announcement_sms_recipient_ids']; include $recipientSelectionView; ?>
		<input type="hidden" name="slsmassnotifyserver_action" value="send_announcement">
		<input type="hidden" name="slsmassnotifyserver_csrf" value="<?php echo htmlspecialchars($csrfToken); ?>">
		<section class="sls-step-card" data-sls-picker="announcement" aria-labelledby="sls-dashboard-destinations-heading">
			<div class="sls-step-heading" id="sls-dashboard-destinations-heading"><span class="sls-step-number">1</span><?php echo _('Destinations'); ?></div>
			<p class="sls-step-subtitle"><?php echo _('Select a saved group, or expand a destination type for individual targets.'); ?></p>
			<div class="sls-groups-toolbar">
				<label><?php echo _('Announcement Groups'); ?> <span class="badge" id="dashboard-announcement-group-count"><?php echo count($announcementGroups); ?></span></label>
				<button type="button" class="btn btn-xs btn-default" id="dashboard-announcement-new-group" <?php echo empty($announcementGroupTargets) && empty($desktopClients) && empty($voiceRecipients) && empty($emailRecipients) && empty($smsRecipients) && empty($announcementWebhooks) ? 'disabled' : ''; ?>><i class="fa fa-plus" aria-hidden="true"></i> <?php echo _('New Group'); ?></button>
			</div>
			<div id="dashboard-announcement-groups" class="sls-group-list"></div>
			<div class="sls-destination-grid">
				<details class="sls-destination-panel">
					<summary>
						<i class="fa fa-phone" aria-hidden="true"></i>
						<span class="sls-destination-label"><?php echo _('Phones'); ?></span>
						<span class="sls-destination-count"><?php echo count($announcementTargets); ?></span>
						<i class="fa fa-chevron-down sls-destination-chevron" aria-hidden="true"></i>
					</summary>
					<div class="sls-destination-body">
						<label class="checkbox-inline">
							<input type="checkbox" name="announcement_all_phones" value="1">
							<?php echo _('All Phones'); ?>
						</label>
						<?php if (empty($announcementTargets)) { ?>
							<p class="help-block sls-compact-help"><?php echo _('No registered PJSIP phones are currently online.'); ?></p>
						<?php } else { ?>
							<div id="dashboard-extension-list" class="sls-target-list">
							<?php foreach ($announcementTargets as $target) { ?>
								<div class="dashboard-extension-row checkbox">
									<label>
										<input type="checkbox" name="announcement_extensions[]" value="<?php echo htmlspecialchars($target['extension']); ?>">
										<?php echo htmlspecialchars($target['extension']); ?>
										<?php if ($target['name'] !== '') { echo ' - ' . htmlspecialchars($target['name']); } ?>
										<span class="text-muted"><?php echo !empty($target['registered']) ? _('registered') : _('offline'); ?></span>
									</label>
								</div>
							<?php } ?>
							</div>
						<?php } ?>
					</div>
				</details>
				<details class="sls-destination-panel">
					<summary>
						<i class="fa fa-desktop" aria-hidden="true"></i>
						<span class="sls-destination-label"><?php echo _('Desktop Apps'); ?></span>
						<span class="sls-destination-count"><?php echo $enabledDesktopCount; ?></span>
						<i class="fa fa-chevron-down sls-destination-chevron" aria-hidden="true"></i>
					</summary>
					<div class="sls-destination-body">
						<label class="checkbox-inline">
							<input type="checkbox" name="announcement_all_desktops" value="1">
							<?php echo _('All Desktops'); ?>
						</label>
						<?php if ($enabledDesktopCount === 0) { ?>
							<p class="help-block sls-compact-help"><?php echo _('No enabled desktop app clients are configured.'); ?></p>
						<?php } else { ?>
							<div class="sls-target-list">
								<?php foreach ($desktopClients as $client) { ?>
									<?php if (empty($client['enabled'])) { continue; } ?>
									<div class="dashboard-desktop-row checkbox">
										<label>
											<input type="checkbox" name="announcement_desktop_clients[]" value="<?php echo htmlspecialchars($client['username'] ?? ''); ?>">
											<?php echo htmlspecialchars($client['name'] ?? 'Desktop App'); ?>
											<span class="text-muted"><?php echo htmlspecialchars($client['client_id'] ?? $client['username'] ?? ''); ?></span>
										</label>
									</div>
								<?php } ?>
							</div>
						<?php } ?>
					</div>
				</details>
				<?php $email_selector_field = 'announcement_email_recipient_ids'; include dirname($recipientSelectionView) . '/announcement_email_selector.php'; ?>
				<?php $sms_selector_field = 'announcement_sms_recipient_ids'; include dirname($recipientSelectionView) . '/announcement_sms_selector.php'; ?>
				<details class="sls-destination-panel">
					<summary><i class="fa fa-phone-square" aria-hidden="true"></i><span class="sls-destination-label"><?php echo _('External Voice'); ?></span><span class="sls-destination-count"><?php echo count($voiceRecipients); ?></span><i class="fa fa-chevron-down sls-destination-chevron" aria-hidden="true"></i></summary>
					<div class="sls-destination-body">
						<?php if (empty($voiceRecipients)) { ?><p class="help-block sls-compact-help"><?php echo _('Enable external voice and save recipients in General Settings.'); ?></p><?php } else { ?>
						<div class="sls-target-list"><?php foreach ($voiceRecipients as $recipient) { ?><div class="checkbox"><label><input type="checkbox" name="voice_recipient_ids[]" value="<?php echo htmlspecialchars((string)($recipient['id'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?>"> <?php echo htmlspecialchars((string)($recipient['name'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?> <span class="text-muted"><?php echo htmlspecialchars((string)($recipient['number'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?></span></label></div><?php } ?></div>
						<p class="help-block sls-compact-help"><?php echo _('External recipients receive calls with the selected announcement audio. Choose an audio mode; text-only delivery cannot call external numbers.'); ?></p>
						<?php } ?>
					</div>
				</details>
				<details class="sls-destination-panel">
					<summary>
						<i class="fa fa-paper-plane" aria-hidden="true"></i>
						<span class="sls-destination-label"><?php echo _('Webhooks'); ?></span>
						<span class="sls-destination-count"><?php echo count($announcementWebhooks); ?></span>
						<i class="fa fa-chevron-down sls-destination-chevron" aria-hidden="true"></i>
					</summary>
					<div class="sls-destination-body">
						<?php if (empty($announcementWebhooks)) { ?>
							<p class="help-block sls-compact-help"><?php echo _('No Dashboard webhooks are configured. Add them under Mass Notify, General Settings.'); ?></p>
						<?php } else { ?>
							<div class="sls-target-list">
								<?php foreach ($announcementWebhooks as $destination) { ?>
									<div class="checkbox"><label>
										<input type="checkbox" name="announcement_webhooks[]" value="<?php echo htmlspecialchars((string)($destination['id'] ?? '')); ?>">
										<?php echo htmlspecialchars((string)($destination['name'] ?? _('Announcement Webhook'))); ?>
									</label></div>
								<?php } ?>
							</div>
							<p class="help-block sls-compact-help"><?php echo _('Each Discord or compatible HTTPS selection receives a branded Discord embed JSON payload.'); ?></p>
						<?php } ?>
					</div>
				</details>
			</div>
			<p class="help-block sls-compact-help"><?php echo _('Groups may include phones, desktop apps, external voice and saved email or SMS recipients. Offline phones are skipped at send time.'); ?></p>
		</section>
		<section class="sls-step-card" aria-labelledby="sls-dashboard-message-heading">
			<div class="sls-step-heading" id="sls-dashboard-message-heading"><span class="sls-step-number">2</span><?php echo _('Message and delivery'); ?></div>
			<div class="sls-composer-grid">
				<div>
					<label for="dashboard_announcement_body"><?php echo _('Announcement Message'); ?></label>
					<textarea class="form-control" id="dashboard_announcement_body" name="announcement_body" rows="3" maxlength="500" placeholder="<?php echo htmlspecialchars(_('Type the announcement')); ?>" aria-describedby="dashboard-announcement-message-help dashboard-announcement-character-count"></textarea>
					<div id="dashboard-announcement-message-help" class="help-block sls-compact-help"><?php echo _('Shown on visual destinations, included in email or SMS, and read aloud when TTS is enabled.'); ?></div>
					<span id="dashboard-announcement-character-count" class="sls-message-count">0 / 500</span>
				</div>
				<div class="sls-option-box">
					<div class="form-group">
						<label for="dashboard_announcement_audio_mode"><?php echo _('Audio'); ?></label>
						<select class="form-control" id="dashboard_announcement_audio_mode" name="announcement_audio_mode">
							<option value="none"><?php echo _('None (visual/text only)'); ?></option>
							<option value="tones"><?php echo _('Tones only'); ?></option>
							<option value="tts"><?php echo _('TTS only'); ?></option>
							<option value="tones_tts" selected><?php echo _('Tones and TTS'); ?></option>
						</select>
					</div>
					<label class="checkbox-inline" style="display:block; margin-left:0;">
						<input type="checkbox" id="dashboard_announcement_colored" name="announcement_colored" value="1">
						<?php echo _('Colored Yealink visual'); ?>
						<span class="label label-success sls-labs-badge"><i class="fa fa-flask" aria-hidden="true"></i> <?php echo _('Labs'); ?></span>
					</label>
				</div>
			</div>
			<div class="sls-tone-grid" id="dashboard_announcement_tone_options">
				<div>
					<label for="dashboard_announcement_opening_tone"><?php echo _('Opening Sound'); ?></label>
					<select class="form-control" id="dashboard_announcement_opening_tone" name="announcement_opening_tone">
						<option value=""><?php echo _('None'); ?></option>
						<?php foreach ($announcementTones as $tone) { ?><option value="<?php echo htmlspecialchars($tone); ?>" <?php echo ($announcementState['opening_tone'] ?? '') === $tone ? 'selected' : ''; ?>><?php echo htmlspecialchars(str_replace('_', ' ', $tone)); ?></option><?php } ?>
						<?php include ($system_recording_options_view ?? dirname(__DIR__, 3).'/views/system_recording_options.php'); ?>
					</select>
				</div>
				<div>
					<label for="dashboard_announcement_closing_tone"><?php echo _('Closing Sound'); ?></label>
					<select class="form-control" id="dashboard_announcement_closing_tone" name="announcement_closing_tone">
						<option value=""><?php echo _('None'); ?></option>
						<?php foreach ($announcementTones as $tone) { ?><option value="<?php echo htmlspecialchars($tone); ?>" <?php echo ($announcementState['closing_tone'] ?? '') === $tone ? 'selected' : ''; ?>><?php echo htmlspecialchars(str_replace('_', ' ', $tone)); ?></option><?php } ?>
						<?php include ($system_recording_options_view ?? dirname(__DIR__, 3).'/views/system_recording_options.php'); ?>
					</select>
				</div>
			</div>
			<div class="sls-color-designer" id="dashboard_announcement_color_designer" aria-hidden="true">
				<div class="row">
					<div class="col-sm-7">
						<div class="form-group">
							<label for="dashboard_announcement_title"><?php echo _('Image Title'); ?></label>
							<input class="form-control" id="dashboard_announcement_title" name="announcement_title" type="text" maxlength="80" value="Announcement">
						</div>
						<div class="form-group">
							<label for="dashboard_announcement_background_color"><?php echo _('Background Color'); ?></label>
							<input class="form-control" id="dashboard_announcement_background_color" name="announcement_background_color" type="color" value="#1f2937" style="max-width: 100px; padding: 3px;">
						</div>
					</div>
					<div class="col-sm-5">
						<label><?php echo _('Color sample'); ?></label>
						<div class="sls-color-preview" id="dashboard_announcement_color_preview">
							<div class="sls-color-preview-title" id="dashboard_announcement_preview_title">Announcement</div>
							<div id="dashboard_announcement_preview_body"><?php echo _('Announcement text'); ?></div>
						</div>
					</div>
				</div>
			</div>
			<p class="help-block sls-compact-help"><?php echo _('Opening and closing sounds are included only when a tone audio mode is selected.'); ?></p>
		</section>
		<div class="sls-preview-actions" aria-label="<?php echo _('Message previews'); ?>">
			<button type="button" class="btn btn-default btn-sm" data-announcement-preview="image"><i class="fa fa-picture-o" aria-hidden="true"></i> <?php echo _('Preview phone image'); ?></button>
			<button type="button" class="btn btn-default btn-sm" data-announcement-preview="internal_speech"><i class="fa fa-volume-up" aria-hidden="true"></i> <?php echo _('Listen: internal'); ?></button>
			<button type="button" class="btn btn-default btn-sm" data-announcement-preview="external_speech"><i class="fa fa-phone" aria-hidden="true"></i> <?php echo _('Listen: external'); ?></button>
            <button type="button" class="btn btn-default btn-sm" data-announcement-preview="sms"><i class="fa fa-commenting-o" aria-hidden="true"></i> <?php echo _('Preview SMS'); ?></button>
		</div>
		<div class="sls-rendered-preview" id="sls-rendered-preview" hidden aria-busy="false">
			<div id="sls-preview-status" role="status" aria-live="polite"></div>
			<div id="sls-preview-media"></div>
			<div id="sls-preview-text" class="sls-preview-text"></div>
		</div>
        <div class="sls-rendered-preview" id="sls-delivery-review" role="status" aria-live="polite" hidden></div>
        <details class="sls-rendered-preview">
            <summary><?php echo _('Delivery rehearsal'); ?> <span class="label label-info"><i class="fa fa-flask" aria-hidden="true"></i> Labs</span></summary>
            <p class="help-block"><?php echo _('Resolve this selection and simulate an outcome. No calls, messages or delivery jobs are created. This does not test a real provider.'); ?></p>
            <label for="sls-rehearsal-outcome"><?php echo _('Simulated outcome'); ?></label>
            <select id="sls-rehearsal-outcome" class="form-control">
                <option value="accepted"><?php echo _('Submission accepted'); ?></option><option value="refused"><?php echo _('Refused before submission'); ?></option>
                <option value="uncertain"><?php echo _('Timeout after possible submission'); ?></option><option value="unavailable"><?php echo _('Recipient unavailable'); ?></option><option value="expired"><?php echo _('Alert expired'); ?></option>
            </select>
            <button type="button" id="sls-rehearsal-run" class="btn btn-default btn-sm"><?php echo _('Run rehearsal — no delivery'); ?></button>
            <pre id="sls-rehearsal-result" role="status" aria-live="polite" style="max-height:320px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere" hidden></pre>
        </details>
		<div class="sls-priority-field">
			<label for="sls-announcement-priority"><?php echo _('Priority'); ?></label>
			<select class="form-control" name="announcement_priority" id="sls-announcement-priority" aria-describedby="sls-priority-help">
				<option value="normal"><?php echo _('Normal'); ?></option>
				<option value="urgent"><?php echo _('Urgent'); ?></option>
			</select>
			<span id="sls-priority-help" class="text-muted" style="font-size:12px"><?php echo _('Urgent audio goes ahead of waiting routine pages, never an active page.'); ?></span>
		</div>
		<div class="sls-action-row">
			<button type="submit" id="dashboard-sls-mass-notify-announcement-submit" class="btn btn-primary sls-send-button" <?php echo $announcementCooldown > 0 ? 'disabled' : ''; ?>>
				<i class="fa fa-circle-o-notch fa-spin sls-submit-spinner" aria-hidden="true"></i><span class="sls-submit-label"><?php echo _('Review and Send'); ?></span>
			</button>
			<span id="dashboard-sls-mass-notify-announcement-cooldown" class="text-muted sls-announcement-cooldown" data-remaining="<?php echo $announcementCooldown; ?>"><?php echo $announcementCooldown > 0 ? sprintf(_('Cooldown: %ss'), $announcementCooldown) : ''; ?></span>
		</div>
		<div id="dashboard-sls-mass-notify-announcement-result" class="sls-announcement-inline-status" role="status" aria-live="polite" aria-atomic="true" aria-busy="false" style="display: none;"></div>
		<div id="sls-announcement-receipts" class="sls-delivery-details"></div>
	</form>
	<div class="modal fade" id="dashboard-announcement-group-modal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<form id="dashboard-announcement-group-form">
					<?php $recipient_selection_form_id = 'dashboard-announcement-group-form'; $recipient_selection_keys = ['group_extensions', 'group_desktop_clients', 'group_voice_recipient_ids', 'group_email_recipient_ids', 'group_sms_recipient_ids', 'group_webhook_ids']; include $recipientSelectionView; ?>
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="<?php echo htmlspecialchars(_('Close')); ?>"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title"><?php echo _('Announcement Group'); ?></h4>
					</div>
					<div class="modal-body">
						<input type="hidden" name="slsmassnotifyserver_action" value="save_announcement_group">
						<input type="hidden" name="slsmassnotifyserver_csrf" value="<?php echo htmlspecialchars($csrfToken); ?>">
						<input type="hidden" id="dashboard_group_id" name="group_id" value="">
						<div class="form-group">
							<label for="dashboard_group_name"><?php echo _('Group Name'); ?></label>
							<input class="form-control" id="dashboard_group_name" name="group_name" type="text" maxlength="64">
						</div>
						<div class="form-group">
							<label><?php echo _('Extensions'); ?></label>
							<?php if (empty($announcementGroupTargets)) { ?>
								<div class="alert alert-warning"><?php echo _('No PJSIP extensions are currently configured.'); ?></div>
							<?php } else { ?>
								<div class="row sls-target-list">
									<?php foreach ($announcementGroupTargets as $target) { ?>
										<div class="col-sm-4">
											<label class="checkbox-inline">
												<input type="checkbox" name="group_extensions[]" value="<?php echo htmlspecialchars($target['extension']); ?>">
												<?php echo htmlspecialchars($target['extension']); ?>
												<?php if ($target['name'] !== '') { ?>
													<?php echo ' - ' . htmlspecialchars($target['name']); ?>
												<?php } ?>
												<span class="text-muted">
													<?php echo !empty($target['registered']) ? _('online') : _('offline'); ?>
												</span>
											</label>
										</div>
									<?php } ?>
								</div>
							<?php } ?>
						</div>
						<div class="form-group">
							<label><?php echo _('Desktop App Clients'); ?></label>
							<?php if (empty($desktopClients)) { ?>
								<div class="alert alert-warning"><?php echo _('No desktop app clients are currently configured.'); ?></div>
							<?php } else { ?>
								<div class="row sls-target-list">
									<?php foreach ($desktopClients as $client) { ?>
										<?php if (empty($client['enabled'])) { continue; } ?>
										<div class="col-sm-6">
											<label class="checkbox-inline">
													<input type="checkbox" name="group_desktop_clients[]" value="<?php echo htmlspecialchars($client['username'] ?? ''); ?>">
													<?php echo htmlspecialchars($client['name'] ?? 'Desktop App'); ?>
													<span class="text-muted"><?php echo htmlspecialchars($client['client_id'] ?? $client['username'] ?? ''); ?></span>
												</label>
											</div>
									<?php } ?>
								</div>
							<?php } ?>
						</div>
						<?php $email_selector_field = 'group_email_recipient_ids'; include dirname($recipientSelectionView) . '/announcement_email_selector.php'; ?>
						<?php $sms_selector_field = 'group_sms_recipient_ids'; include dirname($recipientSelectionView) . '/announcement_sms_selector.php'; ?>
                        <?php $webhook_selector_field = 'group_webhook_ids'; include dirname($recipientSelectionView) . '/audience_webhook_selector.php'; ?>
						<div class="form-group">
							<label><?php echo _('External Voice Recipients'); ?></label>
							<div id="dashboard-group-unavailable-voice"></div>
							<?php if (empty($voiceRecipients)) { ?><p class="text-muted"><?php echo _('No enabled external voice recipients are configured.'); ?></p><?php } else { ?>
							<div class="sls-target-list"><?php foreach ($voiceRecipients as $recipient) { ?><div class="checkbox"><label><input type="checkbox" name="group_voice_recipient_ids[]" value="<?php echo htmlspecialchars((string)($recipient['id'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?>"> <?php echo htmlspecialchars((string)($recipient['name'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?> <span class="text-muted"><?php echo htmlspecialchars((string)($recipient['number'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?></span></label></div><?php } ?></div>
							<?php } ?>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _('Cancel'); ?></button>
						<button type="submit" class="btn btn-primary"><?php echo _('Save Group'); ?></button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
(function() {
	var initialGroups = <?php echo json_encode(array_values($announcementGroups), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
	var onlineExtensions = <?php echo json_encode(array_values(array_map(static function ($target) { return (string)($target['extension'] ?? ''); }, $announcementTargets)), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
	var desktopClients = <?php echo json_encode(array_values(array_map(static function ($client) {
		return array_intersect_key($client, array_flip(['client_id', 'name', 'username', 'enabled']));
	}, $desktopClients)), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE); ?>;
	var emailRecipients = <?php echo json_encode($emailRecipients, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE); ?>;
	var smsRecipients = <?php echo json_encode($smsRecipients, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE); ?>;
	var voiceRecipients = <?php echo json_encode(array_values($voiceRecipients), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE); ?>;
	var root = document.getElementById('dashboard-sls-mass-notify-announcement');
	if (!root || root.getAttribute('data-ready') === '1') {
		return;
	}
	var lifecycleKey = '__slsMassNotifyAnnouncementWidget';
	var previousLifecycle = window[lifecycleKey];
	if (previousLifecycle && typeof previousLifecycle.dispose === 'function') {
		previousLifecycle.dispose();
	}
	var lifecycle = {
		disposed: false,
		intervals: [],
		timeouts: [],
		events: [],
		requests: new Set(),
		resizeObserver: null,
		resizeHandler: null,
		dispose: function() {
			if (this.disposed) {
				return;
			}
			this.disposed = true;
			this.requests.forEach(function(controller) { controller.abort(); });
			this.requests.clear();
			this.intervals.forEach(function(timer) { window.clearInterval(timer); });
			this.timeouts.forEach(function(timer) { window.clearTimeout(timer); });
			this.intervals = [];
			this.timeouts = [];
			this.events.forEach(function(binding) { binding[0].removeEventListener(binding[1], binding[2]); });
			this.events = [];
			if (this.resizeObserver) {
				this.resizeObserver.disconnect();
				this.resizeObserver = null;
			}
			if (this.resizeHandler) {
				window.removeEventListener('resize', this.resizeHandler);
				this.resizeHandler = null;
			}
			if (window[lifecycleKey] === this) {
				window[lifecycleKey] = null;
			}
		}
	};
	window[lifecycleKey] = lifecycle;
	function instanceActive() {
		var attached = !!(document.documentElement && document.documentElement.contains(root));
		if (lifecycle.disposed || window[lifecycleKey] !== lifecycle || !attached) {
			lifecycle.dispose();
			return false;
		}
		return true;
	}
	async function widgetRequest(url, options, maximum) {
		var controller = new AbortController(), timer = window.setTimeout(function() { controller.abort(); }, maximum);
		lifecycle.requests.add(controller);
		try {
			var response = await fetch(url, Object.assign({}, options, {signal: controller.signal, cache: 'no-store'}));
			var data = await parseJsonResponse(response);
			if (!response.ok) { throw new Error(typeof data.message === 'string' ? data.message : 'The PBX returned HTTP ' + response.status + '.'); }
			if (!data || typeof data !== 'object' || Array.isArray(data)) { throw new Error('Invalid PBX response.'); }
			return data;
		} catch (failure) {
			if (controller.signal.aborted) { throw new Error('No complete PBX response within ' + maximum / 1000 + ' seconds, or the widget closed. Check saved settings or delivery details before retrying.'); }
			throw failure;
		} finally {
			window.clearTimeout(timer); lifecycle.requests.delete(controller);
		}
	}
	root.setAttribute('data-ready', '1');
	var form = document.getElementById('dashboard-sls-mass-notify-announcement-form');
	var submit = document.getElementById('dashboard-sls-mass-notify-announcement-submit');
	var cooldown = document.getElementById('dashboard-sls-mass-notify-announcement-cooldown');
	var result = document.getElementById('dashboard-sls-mass-notify-announcement-result');
	var groupResult = document.getElementById('dashboard-sls-mass-notify-group-result');
	var groupList = document.getElementById('dashboard-announcement-groups');
	var groupCount = document.getElementById('dashboard-announcement-group-count');
	var newGroup = document.getElementById('dashboard-announcement-new-group');
	var groupForm = document.getElementById('dashboard-announcement-group-form');
	var groupModal = $('#dashboard-announcement-group-modal');
	var groupId = document.getElementById('dashboard_group_id');
	var groupName = document.getElementById('dashboard_group_name');
	var coloredToggle = document.getElementById('dashboard_announcement_colored');
	var audioMode = document.getElementById('dashboard_announcement_audio_mode');
	var toneOptions = document.getElementById('dashboard_announcement_tone_options');
	var colorDesigner = document.getElementById('dashboard_announcement_color_designer');
	var colorInput = document.getElementById('dashboard_announcement_background_color');
	var titleInput = document.getElementById('dashboard_announcement_title');
	var messageInput = document.getElementById('dashboard_announcement_body');
	var colorPreview = document.getElementById('dashboard_announcement_color_preview');
	var previewTitle = document.getElementById('dashboard_announcement_preview_title');
	var previewBody = document.getElementById('dashboard_announcement_preview_body');
	var messageCount = document.getElementById('dashboard-announcement-character-count');
	var submitLabel = submit ? submit.querySelector('.sls-submit-label') : null;
	var destinationPanels = root.querySelectorAll('.sls-destination-panel');
	var dashboardItem = root.closest ? root.closest('.item') : null;
	var dashboardBox = root.closest ? root.closest('.displaybox') : null;
	if (dashboardItem) {
		dashboardItem.style.maxWidth = '100%';
		dashboardItem.style.minWidth = '0';
		dashboardItem.style.height = 'auto';
		dashboardItem.style.boxSizing = 'border-box';
	}
	if (dashboardBox) {
		dashboardBox.style.maxWidth = '100%';
		dashboardBox.style.minWidth = '0';
		dashboardBox.style.height = 'auto';
		dashboardBox.style.boxSizing = 'border-box';
		var dashboardContent = dashboardBox.querySelector('.content');
		if (dashboardContent) {
			dashboardContent.style.height = 'auto';
			dashboardContent.style.minWidth = '0';
		}
	}
	function scheduleDashboardLayout() {
		if (!instanceActive()) {
			return;
		}
		lifecycle.timeouts.forEach(function(timer) { window.clearTimeout(timer); });
		lifecycle.timeouts = [35, 180].map(function(delay) {
			return window.setTimeout(function() {
				if (!instanceActive()) {
					return;
				}
				var page = $(root).closest('.page');
				if (page.length && typeof page.packery === 'function') {
					page.packery('layout');
				}
			}, delay);
		});
	}
	if (!form || !submit || !cooldown || !result || !groupResult) {
		lifecycle.dispose();
		return;
	}
	function setAnnouncementStatus(level, message, busy) {
		if (!instanceActive()) {
			return;
		}
		var normalizedLevel = ['success', 'warning', 'danger', 'info'].indexOf(level) >= 0 ? level : 'info';
		var iconNames = {success: 'check-circle', warning: 'exclamation-triangle', danger: 'times-circle', info: 'clock-o'};
		result.style.display = 'flex';
		result.className = 'sls-announcement-inline-status sls-status-' + normalizedLevel;
		result.setAttribute('aria-live', normalizedLevel === 'danger' ? 'assertive' : 'polite');
		result.setAttribute('aria-busy', busy ? 'true' : 'false');
		result.innerHTML = '';
		var icon = document.createElement('i');
		icon.className = 'fa fa-' + iconNames[normalizedLevel];
		icon.setAttribute('aria-hidden', 'true');
		var statusText = document.createElement('span');
		statusText.textContent = message;
		result.appendChild(icon);
		result.appendChild(statusText);
		scheduleDashboardLayout();
	}
	function renderMessageCount() {
		if (messageCount && messageInput) {
			messageCount.textContent = String(messageInput.value.length) + ' / 500';
		}
	}
	var groups = Array.isArray(initialGroups) ? initialGroups : [];
	function renderColorDesigner() {
		if (!coloredToggle || !colorDesigner) {
			return;
		}
		var enabled = coloredToggle.checked;
		colorDesigner.style.display = enabled ? 'block' : 'none';
		colorDesigner.setAttribute('aria-hidden', enabled ? 'false' : 'true');
		if (colorPreview && colorInput) {
			var background = /^#[0-9a-f]{6}$/i.test(colorInput.value) ? colorInput.value : '#1f2937';
			var channels = [1, 3, 5].map(function (offset) {
				var value = parseInt(background.slice(offset, offset + 2), 16) / 255;
				return value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
			});
			var luminance = channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
			colorPreview.style.backgroundColor = background;
			colorPreview.style.color = (luminance + 0.05) / 0.05 > 1.05 / (luminance + 0.05) ? '#000000' : '#ffffff';
		}
		if (previewTitle && titleInput) {
			previewTitle.textContent = titleInput.value.trim() || 'Announcement';
		}
		if (previewBody && messageInput) {
			previewBody.textContent = messageInput.value.trim() || 'Announcement text';
		}
		scheduleDashboardLayout();
	}
	function renderAudioOptions() {
		if (audioMode && toneOptions) {
			var showTones = audioMode.value === 'tones' || audioMode.value === 'tones_tts';
			toneOptions.style.display = showTones ? '' : 'none';
			toneOptions.setAttribute('aria-hidden', showTones ? 'false' : 'true');
			scheduleDashboardLayout();
		}
	}
	var renderedPreview = document.getElementById('sls-rendered-preview');
	var previewStatus = document.getElementById('sls-preview-status');
	var previewMedia = document.getElementById('sls-preview-media');
	var previewText = document.getElementById('sls-preview-text');
	var previewButtons = root.querySelectorAll('[data-announcement-preview]');
    var speechMeasurements={};
	function previewInputs() {
		return {message: messageInput.value, title: titleInput.value, color: colorInput.value};
	}
	function clearPreviewMedia() {
		var audio = previewMedia.querySelector('audio');
		if (audio) { audio.pause(); audio.removeAttribute('src'); audio.load(); }
		previewMedia.textContent = ''; previewText.textContent = '';
	}
	previewButtons.forEach(function (button) {
		button.addEventListener('click', function () {
			var values = previewInputs();
			var snapshot = JSON.stringify(values);
			var body = new FormData();
			body.append('slsmassnotifyserver_action', 'preview_announcement');
			body.append('slsmassnotifyserver_csrf', <?php echo json_encode($csrfToken); ?>);
			body.append('kind', button.getAttribute('data-announcement-preview'));
			Object.keys(values).forEach(function (key) { body.append(key, values[key]); });
			clearPreviewMedia(); renderedPreview.hidden = false; renderedPreview.setAttribute('aria-busy', 'true');
			previewStatus.textContent = 'Preparing preview…';
			previewButtons.forEach(function (item) { item.disabled = true; });
			scheduleDashboardLayout();
			widgetRequest(form.action, {method:'POST', credentials:'same-origin', body:body}, 120000)
				.then(function (data) {
					if (!instanceActive()) return;
					if (snapshot !== JSON.stringify(previewInputs())) { previewStatus.textContent = 'The message changed. Prepare a new preview.'; return; }
					if (data.success !== true) { previewStatus.textContent = data.message || 'The preview failed. Check installation diagnostics.'; return; }
                    if (data.kind === 'sms') {
                        if (!Number.isInteger(data.segments) || data.segments < 1 || typeof data.text !== 'string' || typeof data.currency !== 'string') { throw new Error('Invalid SMS preview'); }
                        previewStatus.textContent = data.segments + ' segment(s) per recipient · ' + data.encoding + ' · budgeted ' + (data.budgeted_cost_micros / 1000000).toFixed(4) + ' ' + data.currency + ' per recipient.' + (data.within_limit ? '' : ' Exceeds the configured maximum of ' + data.max_segments + ' segments; sending will be rejected.');
                        previewText.textContent = data.text;
                        return;
                    }
					if (typeof data.data !== 'string' || data.data.length > 14000000 || !/^[A-Za-z0-9+/]+={0,2}$/.test(data.data)
						|| ['image/png','audio/wav'].indexOf(data.mime) < 0) { throw new Error('Invalid preview response'); }
					var media = document.createElement(data.mime === 'image/png' ? 'img' : 'audio');
					media.src = 'data:' + data.mime + ';base64,' + data.data;
					if (data.mime === 'image/png') {
						media.alt = 'Rendered announcement for a 480 by 272 pixel phone display';
						media.width = 480; media.height = 272;
						previewStatus.textContent = data.text_clipped ? 'This phone image cannot show the complete message. Shorten it or use speech for the full instructions.' : 'Phone image · 480 × 272. Text-only phone displays may differ.';
					} else {
						media.controls = true; media.preload = 'metadata';
                        if(Number.isFinite(data.duration_seconds)&&data.duration_seconds>0&&typeof data.speech_revision==='string'){speechMeasurements[button.getAttribute('data-announcement-preview')]={snapshot:snapshot,revision:data.speech_revision,seconds:data.duration_seconds};}
						previewStatus.textContent = 'Speech preview · ' + (button.getAttribute('data-announcement-preview') === 'external_speech' ? 'external calls' : 'internal phones') + '. Opening and closing tones are not included.';
						previewText.textContent = data.speech_text || '';
					}
					previewMedia.appendChild(media);
				}).catch(function () { if (instanceActive()) previewStatus.textContent = 'The preview response was interrupted. Reload the page if your session expired, then try again.'; })
				.finally(function () {
					if (!instanceActive()) return;
					renderedPreview.setAttribute('aria-busy', 'false');
					previewButtons.forEach(function (item) { item.disabled = false; }); scheduleDashboardLayout();
				});
		});
	});
	[messageInput, titleInput, colorInput].forEach(function (input) {
		input.addEventListener('input', function () {
			if (!renderedPreview.hidden) { clearPreviewMedia(); previewStatus.textContent = 'The message changed. Prepare a new preview.'; }
		});
	});
	if (audioMode) {
		audioMode.addEventListener('change', renderAudioOptions);
	}
	[coloredToggle, colorInput, titleInput, messageInput].forEach(function(control) {
		if (control) {
			control.addEventListener(control === coloredToggle ? 'change' : 'input', renderColorDesigner);
		}
	});
	if (messageInput) {
		messageInput.addEventListener('input', renderMessageCount);
	}
	Array.prototype.forEach.call(destinationPanels, function(panel) {
		panel.addEventListener('toggle', scheduleDashboardLayout);
	});
	if (window.ResizeObserver) {
		lifecycle.resizeObserver = new ResizeObserver(scheduleDashboardLayout);
		lifecycle.resizeObserver.observe(root);
	}
	lifecycle.resizeHandler = scheduleDashboardLayout;
	window.addEventListener('resize', lifecycle.resizeHandler);
		var desktopLookup = {};
		(Array.isArray(desktopClients) ? desktopClients : []).forEach(function(client) {
			if (client && client.username) {
				desktopLookup[client.username] = (client.name || client.username) + (client.client_id ? ' (' + client.client_id + ')' : '');
			}
		});
	var onlineLookup = {};
	onlineExtensions.forEach(function(extension) {
		if (extension !== '') {
			onlineLookup[extension] = true;
		}
	});
	function renderGroups() {
		if (!groupList) {
			return;
		}
		if (groupCount) {
			groupCount.textContent = String(groups.length);
		}
		groupList.innerHTML = '';
		if (!groups.length) {
			var empty = document.createElement('div');
			empty.className = 'text-muted';
			empty.textContent = 'No announcement groups created yet.';
			groupList.appendChild(empty);
			return;
		}
		groups.forEach(function(group) {
			var row = document.createElement('div');
			row.className = 'checkbox';
			var label = document.createElement('label');
			var checkbox = document.createElement('input');
			checkbox.type = 'checkbox';
			checkbox.name = 'announcement_groups[]';
			checkbox.value = group.id || '';
			label.appendChild(checkbox);
			label.appendChild(document.createTextNode(' ' + (group.name || 'Group') + ' '));
			var muted = document.createElement('span');
			muted.className = 'text-muted';
			var groupParts = [];
			if ((group.extensions || []).length) {
				groupParts.push('Phones: ' + (group.extensions || []).join(', '));
			}
			if ((group.desktop_clients || []).length) {
				groupParts.push('Desktops: ' + (group.desktop_clients || []).map(function(username) {
					return desktopLookup[username] || username;
				}).join(', '));
			}
			if ((group.email_recipient_ids || []).length) {
				groupParts.push('Email: ' + (group.email_recipient_ids || []).map(function(id) { var recipient = emailRecipients.find(function(row) { return row.id === id; }); return recipient ? recipient.name : 'Unavailable email recipient'; }).join(', '));
			}
			if ((group.sms_recipient_ids || []).length) {
				groupParts.push('SMS: ' + (group.sms_recipient_ids || []).map(function(id) { var recipient = smsRecipients.find(function(row) { return row.id === id; }); return recipient ? recipient.name : 'Unavailable SMS recipient'; }).join(', '));
			}
			if ((group.voice_recipient_ids || []).length) {
				groupParts.push('External voice: ' + (group.voice_recipient_ids || []).map(function(id) {
					var recipient = voiceRecipients.find(function(row) { return row.id === id; });
					return recipient ? recipient.name + ' (' + recipient.number + ')' : 'Unavailable recipient';
				}).join(', '));
			}
			if ((group.webhook_ids || []).length) { groupParts.push('Webhooks: ' + group.webhook_ids.length); }
			muted.textContent = '(' + groupParts.join(' | ') + ')';
			label.appendChild(muted);
			row.appendChild(label);
			var edit = document.createElement('button');
			edit.type = 'button';
			edit.className = 'btn btn-link btn-xs';
			edit.textContent = 'Edit';
			if (group.location_snapshot) {
				edit.disabled = true; edit.textContent = 'Location snapshot';
				edit.title = 'Create a new audience from Locations to change these recipients.';
			}
			edit.addEventListener('click', function() { openGroupModal(group); });
			row.appendChild(edit);
			var del = document.createElement('button');
			del.type = 'button';
			del.className = 'btn btn-link btn-xs text-danger';
			del.textContent = 'Delete';
			del.addEventListener('click', function() { deleteGroup(group.id || ''); });
			row.appendChild(del);
			groupList.appendChild(row);
		});
	}
	function openGroupModal(group) {
		group = group || {};
		groupId.value = group.id || '';
		groupName.value = group.name || '';
		var selected = {};
		(group.extensions || []).forEach(function(extension) { selected[extension] = true; });
		Array.prototype.forEach.call(groupForm.querySelectorAll('input[name="group_extensions[]"]'), function(input) {
			input.checked = !!selected[input.value];
		});
		var selectedDesktops = {};
		(group.desktop_clients || []).forEach(function(username) { selectedDesktops[username] = true; });
		Array.prototype.forEach.call(groupForm.querySelectorAll('input[name="group_desktop_clients[]"]'), function(input) {
			input.checked = !!selectedDesktops[input.value];
		});
		document.getElementById('sls-group-email-recipient-ids').slsEmailSelection(group.email_recipient_ids || []);
		document.getElementById('sls-group-sms-recipient-ids').slsSmsSelection(group.sms_recipient_ids || []);
        document.getElementById('sls-group-webhook-ids').slsWebhookSelection(group.webhook_ids || []);
		var selectedVoice = {};
		(group.voice_recipient_ids || []).forEach(function(id) { selectedVoice[id] = true; });
		Array.prototype.forEach.call(groupForm.querySelectorAll('input[name="group_voice_recipient_ids[]"]'), function(input) {
			input.checked = !!selectedVoice[input.value];
		});
		var unavailableVoice = document.getElementById('dashboard-group-unavailable-voice');
		unavailableVoice.textContent = '';
		(group.voice_recipient_ids || []).forEach(function(id) {
			if (voiceRecipients.some(function(recipient) { return recipient.id === id; })) return;
			var row = document.createElement('div'), label = document.createElement('label'), input = document.createElement('input');
			row.className = 'checkbox text-warning';
			input.type = 'checkbox'; input.name = 'group_voice_recipient_ids[]'; input.value = id; input.checked = true;
			label.appendChild(input); label.appendChild(document.createTextNode(' Unavailable external recipient (' + id + ') — remove this selection or re-enable the recipient.'));
			row.appendChild(label); unavailableVoice.appendChild(row);
		});
		groupModal.modal('show');
	}
	var groupRequestBusy = false;
	function lockGroupControls() {
		var controls = Array.prototype.slice.call(root.querySelectorAll('button,input,select,textarea'));
		var disabled = controls.map(function(control) { return control.disabled; });
		var released = false;
		controls.forEach(function(control) { control.disabled = true; });
		groupRequestBusy = true; groupForm.setAttribute('aria-busy', 'true');
		return function() {
			if (released) { return; } released = true;
			controls.forEach(function(control, index) { control.disabled = disabled[index]; });
			groupRequestBusy = false; groupForm.removeAttribute('aria-busy'); renderCooldown();
		};
	}
	groupModal.on('hide.bs.modal', function(event) { if (groupRequestBusy) event.preventDefault(); });
	function deleteGroup(id) {
		if (!instanceActive()) {
			return;
		}
		if (groupRequestBusy || requestInFlight || activeJob) { return; }
		if (!id || !confirm('Delete this announcement group?')) {
			return;
		}
		var body = new FormData();
		body.append('slsmassnotifyserver_action', 'delete_announcement_group');
		body.append('slsmassnotifyserver_csrf', <?php echo json_encode($csrfToken); ?>);
		body.append('group_id', id);
		var unlock = lockGroupControls();
			widgetRequest(form.action, {method: 'POST', credentials: 'same-origin', body: body}, 30000)
			.then(function(data) {
				if (!instanceActive()) {
					return;
				}
				groupResult.style.display = 'block';
				groupResult.className = 'alert alert-' + (data && data.success === true ? 'success' : 'warning');
				groupResult.textContent = data && data.message ? data.message : 'Group request finished.';
				if (data && data.success === true && Array.isArray(data.groups)) {
					groups = data.groups;
					renderGroups();
				}
			})
				.catch(function(error) {
					if (!instanceActive()) {
						return;
					}
					groupResult.style.display = 'block';
					groupResult.className = 'alert alert-danger';
					groupResult.textContent = 'Group request failed: ' + (error && error.message ? error.message : 'unknown error');
				}).finally(unlock);
	}
		function selectedGroupOfflineExtensions() {
		var offline = {};
		var selectedGroups = {};
		Array.prototype.forEach.call(form.querySelectorAll('input[name="announcement_groups[]"]:checked'), function(input) {
			selectedGroups[input.value] = true;
		});
		groups.forEach(function(group) {
			if (!selectedGroups[group.id || '']) {
				return;
			}
			(group.extensions || []).forEach(function(extension) {
				if (!onlineLookup[extension]) {
					offline[extension] = extension;
				}
			});
		});
			return Object.keys(offline).sort();
		}
		function parseJsonResponse(response) {
			return response.text().then(function(text) {
				try {
					return JSON.parse(text);
				} catch (e) {
					throw new Error(text ? text.replace(/\s+/g, ' ').slice(0, 220) : ('HTTP ' + response.status));
				}
			});
		}
	if (newGroup) {
		newGroup.addEventListener('click', function() { openGroupModal({}); });
	}
	if (groupForm) {
		groupForm.addEventListener('submit', function(event) {
			event.preventDefault();
			if (!instanceActive()) {
				return;
			}
			if (groupRequestBusy || requestInFlight || activeJob) { return; }
			var groupBody = new FormData(groupForm), unlock = lockGroupControls();
				widgetRequest(form.action, {method: 'POST', credentials: 'same-origin', body: groupBody}, 30000)
				.then(function(data) {
					if (!instanceActive()) {
						return;
					}
					groupResult.style.display = 'block';
					groupResult.className = 'alert alert-' + (data && data.success === true ? 'success' : 'warning');
					groupResult.textContent = data && data.message ? data.message : 'Group request finished.';
					if (data && data.success === true && Array.isArray(data.groups)) {
						groups = data.groups;
						renderGroups();
					}
					if (data && data.success === true) {
						unlock();
						groupModal.modal('hide');
					}
				})
					.catch(function(error) {
						if (!instanceActive()) {
							return;
						}
						groupResult.style.display = 'block';
						groupResult.className = 'alert alert-danger';
						groupResult.textContent = 'Group request failed: ' + (error && error.message ? error.message : 'unknown error');
					}).finally(unlock);
		});
	}
	var remaining = parseInt(cooldown.getAttribute('data-remaining') || '0', 10) || 0;
	var deliveryOutcomeUnknown = false;
	var requestInFlight = false;
	var activeJob = '';
	var receiptJob = '', viewedJob = '', receiptDeadline = 0;
	var jobPollBusy = false;
	var receiptsPanel = document.getElementById('sls-announcement-receipts');
	var lastReceiptView = '';
	function showReceipts(data) {
		if (!receiptsPanel) return;
		var rows = Array.isArray(data.receipts) ? data.receipts : [];
		var evidence = data.phone_outcomes;
		var fingerprint = JSON.stringify([rows, evidence, data.receipt_status_error, viewedJob]);
		if (fingerprint === lastReceiptView) return;
		lastReceiptView = fingerprint;
		var wasOpen = !!(receiptsPanel.querySelector('details') && receiptsPanel.querySelector('details').open);
		var needsAttention = rows.some(function(row) { return row.needs_attention !== false && ['failed', 'uncertain', 'cancelled', 'unavailable'].indexOf(row.state) >= 0; });
		receiptsPanel.innerHTML = '';
		if (!rows.length) return;
		var details = document.createElement('details'); details.open = wasOpen || needsAttention;
		var summary = document.createElement('summary'); summary.textContent = 'Delivery details · ' + rows.length + ' destination(s)';
		details.appendChild(summary);
		var list = document.createElement('ul'); list.style.maxHeight = '200px'; list.style.overflowY = 'auto';
		rows.forEach(function(row) {
			var item = document.createElement('li'); item.style.overflowWrap = 'anywhere';
			var receiptState = row.channel === 'email' && row.state === 'accepted' ? 'Accepted by PBX mail service'
				: row.channel === 'webhook' && row.state === 'uncertain' && row.needs_attention === false ? 'Response unconfirmed' : row.state;
			item.textContent = row.channel + ' · ' + row.target + ' · ' + receiptState + (row.detail ? ' — ' + row.detail : '');
			list.appendChild(item);
		});
		details.appendChild(list);
		if (evidence) {
			var note = document.createElement('p');
			note.textContent = 'Phone evidence: ' + (evidence.available ? (evidence.active ? 'calls are active or awaiting start.' : 'call tracking has ended.') : 'no retained call evidence is available.') + ' Answer or conference entry does not confirm full playback or that a person heard the alert.';
			details.appendChild(note);
			var phoneList = document.createElement('ul'); phoneList.style.maxHeight = '200px'; phoneList.style.overflowY = 'auto';
			(Array.isArray(evidence.targets) ? evidence.targets : []).forEach(function(row) {
				var item = document.createElement('li');
				var facts = [];
				if (row.dial_status) facts.push(row.dial_status);
				if (row.answered) facts.push('answered');
				if (row.joined) facts.push('entered conference');
				if (row.playback_completed) facts.push('audio application completed');
				if (row.keypad_acknowledged) facts.push('recipient pressed 1 to acknowledge');
				else if (row.acknowledgement_status === 'pending') facts.push('waiting for keypad acknowledgement');
				else if (row.acknowledgement_status === 'timeout') facts.push('no keypad acknowledgement before timeout');
				else if (row.acknowledgement_status === 'other_key') facts.push('a different key was pressed');
				else if (row.acknowledgement_status === 'prompt_failed') facts.push('keypad prompt or input failed');
				else if (row.acknowledgement_status === 'interrupted') facts.push('call ended before a keypad result was recorded');
				if (row.ended) facts.push('channel ended');
				if (row.uncertain || !facts.length) facts.push('outcome unknown or awaiting events');
				item.textContent = row.recipient_id + ' · attempt ' + row.attempt + ', contact ' + row.contact_index + ' · ' + facts.join(', ');
				phoneList.appendChild(item);
			});
			details.appendChild(phoneList);
			if (evidence.truncated) { var clipped = document.createElement('p'); clipped.textContent = 'Only the first 1,000 contact results are shown.'; details.appendChild(clipped); }
		}
		if (data.receipt_status_error) { var error = document.createElement('p'); error.textContent = data.receipt_status_error; details.appendChild(error); }
		if (viewedJob) {
			var refresh = document.createElement('button'); refresh.type = 'button'; refresh.className = 'btn btn-default btn-sm';
			refresh.textContent = 'Refresh delivery receipts';
			refresh.addEventListener('click', function() { pollJob(true); });
			details.appendChild(refresh);
		}
		receiptsPanel.appendChild(details);
	}
	function renderDeliveryStatus(data) {
		var pending = ['queued', 'worker_starting', 'running'].indexOf(data.state) >= 0 || !!data.queued;
		if (pending) {
			setAnnouncementStatus('info', data.state === 'running' ? 'Sending announcement…' : (data.state === 'worker_starting' ? 'Starting announcement worker…' : 'Announcement queued…'), true);
		} else if (data.success) {
			setAnnouncementStatus('success', 'Announcement submitted' + (data.sender ? ' · Sent by ' + data.sender : ''), false);
		} else {
			setAnnouncementStatus('warning', data.message || 'Delivery needs attention. Check the details before retrying.', false);
		}
	}
	function rememberJob(id) {
		activeJob = /^job_[a-f0-9]{32}$/.test(id || '') ? id : '';
		if (activeJob) { viewedJob = activeJob; receiptJob = ''; }
		try { if (activeJob) sessionStorage.setItem('sls-announcement-job', activeJob); else sessionStorage.removeItem('sls-announcement-job'); } catch (ignored) {}
	}
	function pollJob(manual) {
		if (receiptJob && Date.now() >= receiptDeadline) receiptJob = '';
		var requestedJob = activeJob || receiptJob || (manual === true ? viewedJob : '');
		if (!requestedJob || jobPollBusy || !instanceActive() || (document.hidden && manual !== true) || (requestInFlight && !activeJob)) return;
		jobPollBusy = true;
		widgetRequest('config.php?display=slsmassnotifyserver&slsmassnotifyserver_action=announcement_job&job_id=' + encodeURIComponent(requestedJob), {credentials:'same-origin'}, 10000)
			.then(function(data) {
				if (!instanceActive() || requestedJob !== viewedJob) return;
				var pending = ['queued', 'worker_starting', 'running'].indexOf(data.state) >= 0;
				renderDeliveryStatus(data);
				showReceipts(data); setSubmitBusy(pending);
				if (!pending) {
					rememberJob('');
					receiptJob = data.receipt_poll_pending ? requestedJob : '';
					receiptDeadline = Date.parse(data.created_at || '') + 600000;
					if (!isFinite(receiptDeadline)) receiptJob = '';
					remaining = parseInt(data.cooldown_remaining || '0', 10) || 0;
				}
				renderCooldown();
			}).catch(function() {
				if (instanceActive() && requestedJob === viewedJob) setAnnouncementStatus('warning', activeJob
					? 'Waiting for the PBX delivery result. Do not resend yet.' : 'Receipt refresh failed. Use Refresh delivery receipts to try again.', false);
			}).then(function() { jobPollBusy = false; });
	}
	lifecycle.intervals.push(window.setInterval(pollJob, 2000));
	function setSubmitBusy(busy) {
		requestInFlight = !!busy;
		submit.classList.toggle('sls-submit-busy', requestInFlight);
		submit.setAttribute('aria-busy', requestInFlight ? 'true' : 'false');
		if (submitLabel) {
			submitLabel.textContent = requestInFlight ? 'Working…' : (deliveryReview ? 'Send Announcement' : 'Review and Send');
		}
	}
	function setCooldownText(message, iconName) {
		cooldown.innerHTML = '';
		if (!message) {
			return;
		}
		var icon = document.createElement('i');
		icon.className = 'fa fa-' + iconName;
		icon.setAttribute('aria-hidden', 'true');
		cooldown.appendChild(icon);
		cooldown.appendChild(document.createTextNode(' ' + message));
	}
	function renderCooldown() {
		if (groupRequestBusy) { submit.disabled = true; return; }
		if (requestInFlight) {
			submit.disabled = true;
			setCooldownText('', '');
			return;
		}
		if (deliveryOutcomeUnknown) {
			submit.disabled = true;
			setCooldownText('Checking delivery status…', 'refresh fa-spin');
			return;
		}
		if (remaining > 0) {
			submit.disabled = true;
			setCooldownText('Cooldown: ' + remaining + 's', 'clock-o');
			return;
		}
		submit.disabled = false;
		setCooldownText('', '');
	}
	lifecycle.intervals.push(window.setInterval(function() {
		if (!instanceActive()) {
			return;
		}
		if (remaining > 0) {
			remaining -= 1;
			renderCooldown();
		}
	}, 1000));
	var cooldownPollBusy = false, lastCooldownRefresh = 0;
	function refreshCooldown(force) {
		if (!instanceActive() || document.hidden || cooldownPollBusy
			|| (force !== true && Date.now() - lastCooldownRefresh < 10000)) return;
		cooldownPollBusy = true; lastCooldownRefresh = Date.now();
		widgetRequest('config.php?display=slsmassnotifyserver&slsmassnotifyserver_action=cooldowns', {credentials: 'same-origin'}, 10000)
			.then(function(data) {
				if (!instanceActive()) {
					return;
				}
				if (data && data.cooldowns && data.cooldowns.announcement) {
					deliveryOutcomeUnknown = false;
					remaining = parseInt(data.cooldowns.announcement.remaining || '0', 10) || 0;
					renderCooldown();
				}
			})
			.catch(function() {}).then(function() { cooldownPollBusy = false; });
	}
	function refreshVisibleWidget() {
		if (document.hidden || !instanceActive()) return;
		refreshCooldown(true); pollJob();
	}
	function refreshFocusedWidget() { refreshCooldown(false); }
	document.addEventListener('visibilitychange', refreshVisibleWidget);
	form.addEventListener('focusin', refreshFocusedWidget);
	lifecycle.events.push([document, 'visibilitychange', refreshVisibleWidget], [form, 'focusin', refreshFocusedWidget]);
	lifecycle.intervals.push(window.setInterval(refreshCooldown, 60000));
    var deliveryReview=null, reviewSnapshot='';
    var deliveryReviewPanel=root.querySelector('#sls-delivery-review');
    function deliveryReviewInputs(){
        // Submission briefly disables recipient checkboxes after serializing
        // them. Compare their actual values, not that temporary transport state.
        return JSON.stringify(Array.from(form.querySelectorAll('input[name],select[name],textarea[name]')).filter(function(control){
            return !control.name.startsWith('sls_recipient_selection_')&&!['announcement_review_token','announcement_review','announcement_preview'].includes(control.name);
        }).map(function(control){return [control.name,control.type==='checkbox'||control.type==='radio'?[control.value,control.checked]:control.multiple?Array.from(control.selectedOptions).map(function(option){return option.value;}):control.value];}));
    }
    function clearDeliveryReview(){deliveryReview=null;reviewSnapshot='';deliveryReviewPanel.hidden=true;if(submitLabel&&!requestInFlight)submitLabel.textContent='Review and Send';}
    form.addEventListener('input',clearDeliveryReview);form.addEventListener('change',clearDeliveryReview);
    var rehearsalButton=root.querySelector('#sls-rehearsal-run'),rehearsalResult=root.querySelector('#sls-rehearsal-result');
    rehearsalButton.addEventListener('click',function(){
        if(requestInFlight||!instanceActive()||!form.reportValidity())return;
        clearDeliveryReview();setSubmitBusy(true);rehearsalButton.disabled=true;rehearsalResult.hidden=false;rehearsalResult.textContent='Preparing no-delivery rehearsal…';
        form.dispatchEvent(new CustomEvent('sls:collect-recipients'));
        var body=new FormData(form);body.set('announcement_rehearsal',root.querySelector('#sls-rehearsal-outcome').value);body.set('announcement_preview','1');
        widgetRequest(form.action,{method:'POST',credentials:'same-origin',body:body},30000).then(function(data){
            if(!instanceActive())return;
            if(!data?.success||data.rehearsal?.simulated!==true||data.rehearsal.delivery_started!==false)throw Error(data?.message||'Rehearsal was not confirmed.');
            var result=data.rehearsal,rows=result.simulated_receipts;
            rehearsalResult.textContent=result.message+'\n\n'+Object.entries(result.counts).map(function(entry){return entry[0]+': '+entry[1];}).join(' · ')+'\n\n'+rows.slice(0,100).map(function(row){return row.channel+' · '+row.target+' · '+row.outcome+'\n'+row.detail;}).join('\n\n')+(rows.length>100?'\n\nFirst 100 of '+rows.length+' synthetic outcomes shown.':'');
            scheduleDashboardLayout();
        }).catch(function(error){if(instanceActive())rehearsalResult.textContent=error.message;}).finally(function(){if(instanceActive()){setSubmitBusy(false);rehearsalButton.disabled=false;renderCooldown();}});
    });
	form.addEventListener('submit', function(event) {
		event.preventDefault();
		if (!instanceActive()) {
			return;
		}
		if (remaining > 0 || requestInFlight || deliveryOutcomeUnknown || activeJob || groupRequestBusy) {
			return;
		}
		if (root.getAttribute('data-quiet-hours-active') === '1') {
			if (!confirm('⚠ You are currently inside quiet hours. Are you sure you want to send this message after paging hours?')) {
				return;
			}
		}
		var offlineExtensions = selectedGroupOfflineExtensions();
		if (offlineExtensions.length > 0) {
			if (!confirm('⚠ Not all extensions in the selected announcement group are online. Offline extensions will be skipped: ' + offlineExtensions.join(', ') + '. Send to online extensions only?')) {
				return;
			}
		}
		receiptJob = ''; viewedJob = '';
		setSubmitBusy(true);
		renderCooldown();
		showReceipts({receipts: []});
		setAnnouncementStatus('info', 'Queueing announcement…', true);
		deliveryOutcomeUnknown = false;
		var body = new FormData(form);
        var currentReviewInputs=deliveryReviewInputs();
        if(!deliveryReview||reviewSnapshot!==currentReviewInputs||Date.parse(deliveryReview.expires_at)<=Date.now()){
            body.set('announcement_preview','1');body.set('announcement_review','1');
            setAnnouncementStatus('info','Preparing delivery review…',true);
            widgetRequest(form.action,{method:'POST',credentials:'same-origin',body:body},30000).then(function(data){
                if(!instanceActive())return;
                if(currentReviewInputs!==deliveryReviewInputs()){clearDeliveryReview();setAnnouncementStatus('warning','Selection changed. Send again to review the current recipients.');return;}
                if(!data||data.success!==true||!data.review){throw new Error(data?.message||'Delivery review could not be prepared.');}
                deliveryReview=data.review;reviewSnapshot=currentReviewInputs;deliveryReviewPanel.replaceChildren();
                var heading=document.createElement('strong');heading.textContent='Delivery review';deliveryReviewPanel.append(heading);
                var summary=document.createElement('p');summary.textContent=Object.entries(deliveryReview.counts).filter(function(entry){return entry[1]>0;}).map(function(entry){return entry[1]+' '+entry[0].replaceAll('_',' ');}).join(' · ');deliveryReviewPanel.append(summary);
                if(deliveryReview.unavailable_phones.length){var offline=document.createElement('p');offline.textContent='Unavailable phone contacts: '+deliveryReview.unavailable_phones.join(', ');deliveryReviewPanel.append(offline);}
                var detail=document.createElement('details'),caption=document.createElement('summary'),targets=document.createElement('ul');caption.textContent='Selected recipients';detail.append(caption);Object.entries(deliveryReview.recipients).forEach(function(entry){if(!entry[1].length)return;var line=document.createElement('li');line.textContent=entry[0].replaceAll('_',' ')+': '+entry[1].join(', ');targets.append(line);});detail.append(targets);deliveryReviewPanel.append(detail);
                var speech=document.createElement('p');
                var measured=speechMeasurements.internal_speech,externalMeasured=speechMeasurements.external_speech;
                var duration=measured&&measured.snapshot===JSON.stringify(previewInputs())&&measured.revision===deliveryReview.speech.revision?' Measured speech: '+measured.seconds.toFixed(2)+' seconds.':'';
                if(externalMeasured&&externalMeasured.snapshot===JSON.stringify(previewInputs())&&externalMeasured.revision===deliveryReview.speech.external_revision)duration+=' External speech: '+externalMeasured.seconds.toFixed(2)+' seconds.';
                speech.textContent='Audio: '+deliveryReview.speech.mode+'. Speech limit: '+deliveryReview.speech.maximum_seconds+' seconds.'+(deliveryReview.speech.gateway_maximum_seconds?' Radio gateway full-sequence limit: '+deliveryReview.speech.gateway_maximum_seconds+' seconds.':'')+duration+(duration?' Opening and closing tones are additional.':' Listen to a speech preview to measure it.');deliveryReviewPanel.append(speech);
                if(deliveryReview.sms){var cost=document.createElement('p');cost.textContent='SMS: '+deliveryReview.sms.segments_per_recipient+' unit(s) per recipient; estimated '+(deliveryReview.sms.estimated_cost_micros/1000000).toFixed(4)+' '+deliveryReview.sms.currency+'. Provider billing may differ.';deliveryReviewPanel.append(cost);}
                var action=document.createElement('p');action.textContent='Check the selection, then press Send announcement again to submit. Changes require a new review.';deliveryReviewPanel.append(action);deliveryReviewPanel.hidden=false;
                setAnnouncementStatus('info','Review ready. No delivery has started.');scheduleDashboardLayout();
            }).catch(function(error){clearDeliveryReview();setAnnouncementStatus('danger',error.message);}).finally(function(){if(instanceActive()){setSubmitBusy(false);renderCooldown();}});
            return;
        }
        body.set('announcement_review_token',deliveryReview.token);clearDeliveryReview();
			widgetRequest(form.action, {method: 'POST', credentials: 'same-origin', body: body}, 30000)
			.then(function(data) {
				if (!instanceActive()) {
					return;
				}
				renderDeliveryStatus(data || {});
				if (data && data.queued && data.job_id) {
					rememberJob(data.job_id); setSubmitBusy(true); pollJob(); renderCooldown(); return;
				}
				showReceipts(data || {});
				setSubmitBusy(false);
				deliveryOutcomeUnknown = false;
				remaining = parseInt((data && data.cooldown_remaining) || '0', 10) || 0;
				renderCooldown();
			})
				.catch(function(error) {
					if (!instanceActive()) {
						return;
					}
					setSubmitBusy(false);
					deliveryOutcomeUnknown = true;
					setAnnouncementStatus(
						'danger',
						'Announcement response could not be confirmed. Wait for cooldown status before retrying.',
						false
					);
					renderCooldown();
				});
	});
	renderGroups();
	renderColorDesigner();
	renderAudioOptions();
	renderMessageCount();
	setSubmitBusy(false);
	renderCooldown();
	scheduleDashboardLayout();
	try { rememberJob(sessionStorage.getItem('sls-announcement-job') || ''); } catch (ignored) {}
	if (activeJob) { setSubmitBusy(true); renderCooldown(); pollJob(); }
}());
</script>

<?php $source_picker_choices = $source_picker_choices ?? []; $source_picker_mode = 'announcement'; include dirname($recipientSelectionView) . '/audience_source_picker.php'; ?>
