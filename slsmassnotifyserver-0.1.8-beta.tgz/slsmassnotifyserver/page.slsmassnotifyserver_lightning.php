<?php
require_once __DIR__.'/AdminResponse.php';

$slsmassnotifyserver = \FreePBX::create()->Slsmassnotifyserver;
$slsmassnotifyserver->enforceOperatorPageAccess('slsmassnotifyserver_lightning');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'
    && (($_POST['ajax'] ?? '') === '1' || ($_POST['slsmassnotifyserver_action'] ?? '') === 'test_delivery_status')) {
    \SLS\MassNotify\AdminResponse::requireClearBuffers();
}
$saveResult = $_SESSION['slsmassnotifyserver_lightning_save_result'] ?? null;
$applyResult = $_SESSION['slsmassnotifyserver_lightning_apply_result'] ?? null;
$testResult = $_SESSION['slsmassnotifyserver_lightning_test_result'] ?? null;
$connectionResult = $_SESSION['slsmassnotifyserver_lightning_connection_result'] ?? null;
unset(
	$_SESSION['slsmassnotifyserver_lightning_save_result'],
	$_SESSION['slsmassnotifyserver_lightning_apply_result'],
	$_SESSION['slsmassnotifyserver_lightning_test_result'],
	$_SESSION['slsmassnotifyserver_lightning_connection_result']
);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$slsmassnotifyserver->validateCsrfToken($_POST['slsmassnotifyserver_csrf'] ?? '')) {
	$result = [
		'success' => false,
		'message' => _('The request security token is invalid or expired. Reload the page and try again.'),
		'errors' => [],
	];
	if (($_POST['ajax'] ?? '') === '1') {
		http_response_code(403);
		header('Content-Type: application/json');
		header('Cache-Control: no-store');
		echo json_encode($result, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
		exit;
	}
	$_SESSION['slsmassnotifyserver_lightning_save_result'] = $result;
	header('Location: config.php?display=slsmassnotifyserver_lightning');
	exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$action = $_POST['slsmassnotifyserver_action'] ?? '';
	if ($action === 'test_delivery_status') {
		header('Content-Type: application/json'); header('Cache-Control: private, no-store');
		try { echo json_encode($slsmassnotifyserver->getTestDeliveryStatus($_POST['delivery_ticket'] ?? null), JSON_THROW_ON_ERROR); }
		catch (\Throwable $error) { http_response_code(400); echo json_encode(['success'=>false,'message'=>'The test delivery report expired or is unavailable.']); }
		exit;
	}
	if ($action === 'save_lightning_settings') {
		$_SESSION['slsmassnotifyserver_lightning_save_result'] = $slsmassnotifyserver->saveLightningSettings($_POST);
	} elseif ($action === 'apply_settings') {
		$_SESSION['slsmassnotifyserver_lightning_apply_result'] = $slsmassnotifyserver->applySettings();
	} elseif ($action === 'test_lightning') {
		$triggerName = isset($_SESSION['AMP_user']->username) && $_SESSION['AMP_user']->username !== ''
			? (string)$_SESSION['AMP_user']->username
			: 'FreePBX Dashboard';
		if (($_POST['ajax'] ?? '') === '1' && session_status() === PHP_SESSION_ACTIVE) {
			session_write_close();
		}
		try {
			$selectedGroupIds = is_array($_POST['lightning_group_ids'] ?? null)
				? $_POST['lightning_group_ids']
				: [];
			$result = $slsmassnotifyserver->triggerLightningTest($triggerName, $selectedGroupIds);
		} catch (\Throwable $e) {
			error_log('SLS Mass Notify Lightning test response failed: ' . $e->getMessage());
			$result = [
				'success' => false,
				'message' => _('Lightning test could not return a confirmed delivery result.'),
				'errors' => [_('Review Notification Logs and Dashboard health for the failed delivery stage.')],
			];
		}
		if (($_POST['ajax'] ?? '') === '1') {
			header('Content-Type: application/json');
			header('Cache-Control: no-store');
			$result['cooldown'] = $slsmassnotifyserver->getLightningTestCooldownState();
			echo json_encode($result, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
			exit;
		}
		$_SESSION['slsmassnotifyserver_lightning_test_result'] = $result;
	} elseif ($action === 'verify_lightning_connection') {
		$_SESSION['slsmassnotifyserver_lightning_connection_result'] = $slsmassnotifyserver->verifyLightningConnection();
	}
	header('Location: config.php?display=slsmassnotifyserver_lightning');
	exit;
}

echo $slsmassnotifyserver->showPage('lightning', [
	'save_result' => $saveResult,
	'apply_result' => $applyResult,
	'test_result' => $testResult,
	'connection_result' => $connectionResult,
]);
